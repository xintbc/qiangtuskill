/* ============================================================================
   枪战突击 · 开服器「内核升级」工具
   ----------------------------------------------------------------------------
   由开服器（电脑 EXE / 手机 APK）用自带的 node 运行，电脑手机共用这一份：

     node 内核升级.js check <内核目录>
         → 只看有没有新版，最后一行输出 JSON：
           {"ok":1,"now":"1.9.45","new":"1.9.46","need":1,"size":1123456,"notes":"..."}
           出错 {"ok":0,"err":"连不上下载站"}

     node 内核升级.js apply <内核目录> <临时目录>
         → 下载 + 解压覆盖 <内核目录>，最后一行 {"ok":1,"ver":"1.9.46"}

   为什么要用 node 干这件事：
     · 下载要 HTTPS，C（WinHTTP）和 Java（HttpURLConnection）两套写法；
     · 解压要 zip，Windows 的 tar 对中文文件名不稳，Java 又要另写一遍；
     · 而两个平台的客户端里本来就带着 node，一份脚本两端通用。

   ⚠️ 升级绝不碰：
     · config/ 之类的外部配置（不在这棵目录里，天然安全）
     · mode/模组/ 里玩家自己导入的模组（下面 SKIP 明确跳过）
     · 内核目录里原本就有、但新包里没有的文件（比如 node.exe / 手机版的一堆 .so，
       内核包故意不带，省得每次升级都要下 90MB）
   ============================================================================ */
'use strict';

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const https = require('https');
const http = require('http');

/* 版本下载站（跟游戏客户端、启动器读的是同一个 manifest.json） */
const 站址 = process.env.GUN_SITE || 'https://xintbc.github.io/qiangtuskill/';
/* 这些路径不覆盖：用户自己的模组 */
const SKIP = ['mode/模组/'];

function 最后一行(obj) {
  process.stdout.write('\n@@RESULT@@' + JSON.stringify(obj) + '\n');
}
function 退(码) { process.exitCode = 码 || 0; }

/* ---------------------------------------------------------------- 网络 */
function 取(地址, 跳数) {
  跳数 = 跳数 || 0;
  return new Promise(function (成, 败) {
    if (跳数 > 5) return 败(new Error('重定向太多次'));
    const lib = 地址.indexOf('https:') === 0 ? https : http;
    const req = lib.get(地址, {
      timeout: 20000,
      headers: { 'User-Agent': 'QiangTu-Kaifuqi/1.0', 'Cache-Control': 'no-cache' }
    }, function (res) {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        res.resume();
        return 取(new URL(res.headers.location, 地址).toString(), 跳数 + 1).then(成, 败);
      }
      if (res.statusCode !== 200) {
        res.resume();
        return 败(new Error('HTTP ' + res.statusCode));
      }
      const 块 = [];
      let 长度 = 0, 上限 = 60 * 1024 * 1024;
      res.on('data', function (c) {
        长度 += c.length;
        if (长度 > 上限) { req.destroy(); return 败(new Error('文件太大')); }
        块.push(c);
      });
      res.on('end', function () { 成(Buffer.concat(块)); });
    });
    req.on('timeout', function () { req.destroy(); 败(new Error('网络超时')); });
    req.on('error', 败);
  });
}

/* ---------------------------------------------------------------- 极简 zip 解包
   只认 store(0) 和 deflate(8)，够用了 —— 发布包就是 python zipfile 打的。 */
function 解包(buf) {
  const 表 = [];
  /* 找中央目录结束标记 EOCD（从尾部往前扫，注释最长 64KB） */
  let eo = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65558); i--) {
    if (buf.readUInt32LE(i) === 0x06054b50) { eo = i; break; }
  }
  if (eo < 0) throw new Error('不是有效的 zip 文件');
  const 条数 = buf.readUInt16LE(eo + 10);
  let p = buf.readUInt32LE(eo + 16);

  for (let i = 0; i < 条数; i++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('zip 目录损坏');
    const 旗 = buf.readUInt16LE(p + 8);
    const 方式 = buf.readUInt16LE(p + 10);
    const 大 = buf.readUInt32LE(p + 20);
    const 名长 = buf.readUInt16LE(p + 28);
    const 扩长 = buf.readUInt16LE(p + 30);
    const 注长 = buf.readUInt16LE(p + 32);
    const 头 = buf.readUInt32LE(p + 42);
    let 名 = buf.slice(p + 46, p + 46 + 名长);
    if (!(旗 & 0x800)) { try { 名 = Buffer.from(名.toString('utf8'), 'utf8'); } catch (e) { } }
    const 名串 = 名.toString('utf8').replace(/\\/g, '/');

    当前名 = 名串;
    if (!/\/$/.test(名串)) {
      /* 本地文件头：名字/扩展字段长度可能和中央目录不同，以本地头为准 */
      if (buf.readUInt32LE(头) !== 0x04034b50) throw new Error('zip 局部头损坏：' + 名串);
      const 局名 = buf.readUInt16LE(头 + 26);
      const 局扩 = buf.readUInt16LE(头 + 28);
      const 起 = 头 + 30 + 局名 + 局扩;
      const 压 = buf.slice(起, 起 + 大);
      let 原;
      if (方式 === 0) 原 = 压;
      else if (方式 === 8) 原 = zlib.inflateRawSync(压);
      else throw new Error('不支持的压缩方式 ' + 方式 + '：' + 名串);
      表.push({ 名: 名串, 数据: 原 });
    }
    p += 46 + 名长 + 扩长 + 注长;
  }
  return 表;
}
let 当前名 = '';

/* ---------------------------------------------------------------- 版本比较 */
function 比版本(a, b) {
  const pa = String(a || '').replace(/^v/i, '').split(/[.\-+]/);
  const pb = String(b || '').replace(/^v/i, '').split(/[.\-+]/);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const x = parseInt(pa[i], 10), y = parseInt(pb[i], 10);
    if (isNaN(x) || isNaN(y)) {
      const s = String(pa[i] || '').localeCompare(String(pb[i] || ''));
      if (s) return s > 0 ? 1 : -1;
      continue;
    }
    if (x !== y) return x > y ? 1 : -1;
  }
  return 0;
}

function 读本地版本(内核目录) {
  try {
    const v = fs.readFileSync(path.join(内核目录, '内核版本.txt'), 'utf8').trim();
    if (v) return v.split(/\s+/)[0];
  } catch (e) { }
  return '';
}

/* ---------------------------------------------------------------- 主流程 */
async function 查最新() {
  const j = JSON.parse((await 取(站址 + 'manifest.json?t=' + Date.now())).toString('utf8'));
  const 列 = Array.isArray(j.内核) ? j.内核 : [];
  if (!列.length) throw new Error('下载站上还没有内核包');
  return 列;                                  // 打包脚本按新→旧排列，第 0 个就是最新
}

async function check(内核目录) {
  const 现在 = 读本地版本(内核目录);
  const 列 = await 查最新();
  const 新 = 列[0];
  const 需 = !现在 || 比版本(新.版本, 现在) > 0;
  最后一行({
    ok: 1, now: 现在 || '未知', new: 新.版本, need: 需 ? 1 : 0,
    size: 新.大小 || 0, notes: 新.说明 || '', file: 新.文件 || '', date: 新.日期 || ''
  });
}

async function apply(内核目录, 临时目录) {
  const 现在 = 读本地版本(内核目录);
  const 列 = await 查最新();
  const 新 = 列[0];
  if (!新 || !新.文件) throw new Error('下载站上还没有内核包');
  if (现在 && 比版本(新.版本, 现在) <= 0) {
    最后一行({ ok: 1, ver: 现在, 已经最新: 1 });
    return;
  }

  fs.mkdirSync(临时目录, { recursive: true });
  const 压 = path.join(临时目录, 'kernel.zip');
  process.stdout.write('正在下载内核 ' + 新.版本 + ' ...\n');
  const buf = await 取(站址 + '内核/' + encodeURIComponent(新.文件) + '?t=' + Date.now());
  if (新.大小 && Math.abs(buf.length - 新.大小) > 16) {
    throw new Error('下载不完整（' + buf.length + '/' + 新.大小 + ' 字节）');
  }
  fs.writeFileSync(压, buf);
  process.stdout.write('下载完成 ' + (buf.length / 1048576).toFixed(2) + ' MB，开始解压...\n');

  const 表 = 解包(buf);
  let 写 = 0, 跳 = 0;
  for (const f of 表) {
    if (SKIP.some(function (s) { return f.名.indexOf(s) === 0; })) { 跳++; continue; }
    if (f.名.indexOf('..') >= 0) { 跳++; continue; }
    const abs = path.join(内核目录, f.名);
    if (abs.indexOf(path.resolve(内核目录)) !== 0) { 跳++; continue; }
    fs.mkdirSync(path.dirname(abs), { recursive: true });
    fs.writeFileSync(abs, f.数据);
    写++;
  }
  /* 版本标记：下次 check 就靠它 */
  try {
    fs.writeFileSync(path.join(内核目录, '内核版本.txt'),
      String(新.版本) + '\n' + (新.日期 || '') + '\n', 'utf8');
  } catch (e) { }

  process.stdout.write('解压完成：更新 ' + 写 + ' 个文件，跳过 ' + 跳 + ' 个（玩家模组不动）\n');
  最后一行({ ok: 1, ver: 新.版本, files: 写, skipped: 跳 });
}

(async function () {
  const mode = (process.argv[2] || '').toLowerCase();
  const 内核目录 = process.argv[3] || '';
  const 临时目录 = process.argv[4] || path.join(require('os').tmpdir(), 'qiangtu-kernel');
  try {
    if (!内核目录) throw new Error('缺少内核目录参数');
    if (mode === 'check') await check(内核目录);
    else if (mode === 'apply') await apply(内核目录, 临时目录);
    else throw new Error('未知模式：' + mode);
  } catch (e) {
    最后一行({ ok: 0, err: (e && e.message) || String(e), where: 当前名 });
    退(1);
  }
})();
