/* 【1.10.9】月球主题枪皮「引力」（js/71_引力枪皮.js）=====================================
   用户口径（原话拆解）：
     · 引力主题枪皮，弹夹容量 **8**，**伤害 ×4**；
     · 装弹特殊：屏幕**左边飘来一个弹夹**，手伸过去把弹夹拿过来再装到枪上；
     · 枪上有个**月球挂饰**；**前握把是月球那种颜色**（月岩灰）；
     · 检视时玩家把它**抛向空中、悬浮在正中间旋转**；
     · 狙击枪，**每开一枪都要拉一次栓**，拉栓要时间；装弹慢。

   实现分工（照 js/69 万圣枪皮的先例，全部用包装，不改老分片函数体）：
     · 本分片注册 `BUILTIN_GUNS[-3]`（-1 长明 / -2 南瓜 / 2+ 模组枪）；
     · 第一人称模型 = 第三人称模型（js/20 的 _TP复制第一人称 直接复制 def.build）；
     · 弹匣：包装 buildMagazineGroup，magType==='gravity' 时给自己的弹匣；
     · 拉栓：def.boltAction/boltTime，包装 attack（拉栓中不许开火）+ updatePlayer 推进动画；
     · 换弹动画（左侧飞弹夹）与检视（抛空悬浮）在 js/24 里按 def.reloadAnim / inspectAnim 分支。
   ⚠️ 本分片排在 js/70 之后（最后），跨分片调用一律 typeof 守卫。 */

var GRAVITY_SLOT = -3;
var 引力枪皮键 = 'gunGame.gravSkin.v1';
var 引力枪皮名 = '引力';
var 引力皮价 = 300;

/* ==================== 一、解锁 / 购买（同万圣枪皮那套） ==================== */
function 引力已解锁() {
  try { return localStorage.getItem(引力枪皮键) === '1'; } catch (e) { return false; }
}
function 引力解锁(静默) {
  try { localStorage.setItem(引力枪皮键, '1'); } catch (e) { }
  引力刷新锁();
  if (!静默) { try { showMsg('🌑 已解锁枪皮「引力」！按 B 打开武器界面装备', '#9fd8ff'); } catch (e) { } }
}
function 引力刷新锁() {
  var d = BUILTIN_GUNS[GRAVITY_SLOT]; if (!d) return;
  var 有 = 引力已解锁();
  d.锁 = !有;
  d.锁提示 = 有 ? '' : '未购买 · 去主菜单「枪械购买」用 ' + 引力皮价 + ' 枪皮币解锁';
}
/* 商店购买钩子（枪皮商店点击时调用，名字与万圣保持一致的口径） */
function 引力购买尝试() {
  if (引力已解锁()) return true;
  try {
    if (typeof 枪皮币 !== 'number' || 枪皮币 < 引力皮价) {
      showMsg('枪皮币不足：需要 ' + 引力皮价 + '（当前 ' + (typeof 枪皮币 === 'number' ? 枪皮币 : 0) + '）', '#ffd166');
      return false;
    }
  } catch (e) { }
  try { 枪皮币 -= 引力皮价; if (typeof 存枪皮币 === 'function') 存枪皮币(); } catch (e) { }
  引力解锁(false);
  return true;
}

/* ==================== 二、模型：狙击枪 + 月球挂饰 + 月岩前握把 ==================== */
function _建引力枪(g) {
  /* 尺寸基准：握把在 z≈0.08，枪口 z≈-0.92，全长约 1.0 米 —— 比纪念枪更长、更像重狙。
     y=0 是枪膛轴线；瞄镜在轴线之上（+y），弹匣在轴线之下（-y）。 */
  var 月岩 = new THREE.MeshLambertMaterial({ color: 0xb9c2cc, side: THREE.DoubleSide });  // 月岩灰（前握把/护木）
  var 月岩暗 = new THREE.MeshLambertMaterial({ color: 0x8d97a3, side: THREE.DoubleSide });
  var 身 = new THREE.MeshLambertMaterial({ color: 0x1b2230, side: THREE.DoubleSide });     // 深空蓝黑枪身
  var 身深 = new THREE.MeshLambertMaterial({ color: 0x0f141d, side: THREE.DoubleSide });
  var 钢 = new THREE.MeshLambertMaterial({ color: 0x9aa4b2, side: THREE.DoubleSide });
  var 蓝 = new THREE.MeshBasicMaterial({ color: 0x6ec8ff, side: THREE.DoubleSide });       // 引力能量蓝
  var 蓝暗 = new THREE.MeshLambertMaterial({ color: 0x2a6f9e, side: THREE.DoubleSide });
  var 月面 = new THREE.MeshLambertMaterial({ color: 0xdfe4ea, side: THREE.DoubleSide });   // 挂饰月球
  var 月坑 = new THREE.MeshLambertMaterial({ color: 0xa8b2bd, side: THREE.DoubleSide });

  function bx(w, h, d, m, x, y, z, rx, ry, rz) {
    var o = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);
    o.position.set(x || 0, y || 0, z || 0);
    if (rx) o.rotation.x = rx; if (ry) o.rotation.y = ry; if (rz) o.rotation.z = rz;
    g.add(o); return o;
  }
  function cy(rt, rb, len, m, x, y, z, rx, seg) {
    var o = new THREE.Mesh(new THREE.CylinderGeometry(rt, rb, len, seg || 16), m);
    o.position.set(x || 0, y || 0, z || 0); if (rx) o.rotation.x = rx; g.add(o); return o;
  }

  /* ---------- 机匣 ---------- */
  bx(0.060, 0.056, 0.290, 身, 0, 0.018, -0.030);          // 上机匣
  bx(0.058, 0.046, 0.250, 身, 0, -0.026, -0.020);          // 下机匣
  bx(0.062, 0.010, 0.290, 身深, 0, -0.004, -0.030);        // 机匣分界
  bx(0.004, 0.010, 0.250, 蓝, -0.0315, 0.020, -0.030);     // 左侧能量条
  bx(0.004, 0.010, 0.250, 蓝, 0.0315, 0.020, -0.030);      // 右侧能量条
  /* 抛壳窗凹槽 */
  bx(0.005, 0.004, 0.075, 身深, 0.0322, 0.034, 0.010);
  bx(0.005, 0.004, 0.075, 身深, 0.0322, 0.010, 0.010);
  bx(0.005, 0.026, 0.004, 身深, 0.0322, 0.022, 0.048);

  /* ---------- 长枪管 + 制退器 ---------- */
  cy(0.014, 0.014, 0.560, 钢, 0, 0.018, -0.470, Math.PI / 2, 20);
  cy(0.020, 0.018, 0.070, 身深, 0, 0.018, -0.775, Math.PI / 2, 18);   // 制退器
  bx(0.048, 0.010, 0.030, 蓝, 0, 0.018, -0.700);                      // 枪口能量环
  /* 导气箍 / 两脚架接口 */
  bx(0.044, 0.030, 0.036, 身, 0, 0.018, -0.250);

  /* ---------- 前护木（月岩色）+ 前握把（月岩色，用户点名） ---------- */
  bx(0.052, 0.044, 0.150, 月岩, 0, 0.008, -0.230);                    // 护木
  bx(0.054, 0.008, 0.150, 月岩暗, 0, 0.030, -0.230);                  // 护木上沿
  /* 前握把：竖直握把，表面做出"月面坑"的浅色斑块 */
  bx(0.036, 0.110, 0.040, 月岩, 0, -0.075, -0.205, 0.10);
  bx(0.040, 0.012, 0.044, 月岩暗, 0, -0.130, -0.200, 0.10);           // 握把底盖
  (function () {                                                       // 月面坑（3 个浅色凹点）
    var 坑 = [[-0.009, -0.048], [0.010, -0.070], [-0.004, -0.098]];
    for (var i = 0; i < 坑.length; i++) {
      var d = new THREE.Mesh(new THREE.CylinderGeometry(0.007, 0.007, 0.004, 10), 月岩暗);
      d.rotation.x = Math.PI / 2 + 0.10;
      d.position.set(坑[i][0], 坑[i][1], -0.1865);
      g.add(d);
    }
  })();

  /* ---------- 瞄镜（大倍镜，开镜时整件隐藏 → scope 标记） ---------- */
  (function () {
    var 镜组 = new THREE.Group();
    var 管 = new THREE.Mesh(new THREE.CylinderGeometry(0.024, 0.024, 0.230, 20), 身);
    管.rotation.x = Math.PI / 2; 管.position.set(0, 0.086, -0.060); 镜组.add(管);
    var 前 = new THREE.Mesh(new THREE.CylinderGeometry(0.032, 0.026, 0.070, 20), 身深);
    前.rotation.x = Math.PI / 2; 前.position.set(0, 0.086, -0.200); 镜组.add(前);
    var 后 = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.024, 0.055, 20), 身深);
    后.rotation.x = Math.PI / 2; 后.position.set(0, 0.086, 0.068); 镜组.add(后);
    var 片 = new THREE.Mesh(new THREE.CylinderGeometry(0.020, 0.020, 0.006, 20),
      new THREE.MeshBasicMaterial({ color: 0x6ec8ff, transparent: true, opacity: 0.55 }));
    片.rotation.x = Math.PI / 2; 片.position.set(0, 0.086, -0.234); 镜组.add(片);
    /* 镜座 */
    var 座1 = new THREE.Mesh(new THREE.BoxGeometry(0.028, 0.036, 0.018), 钢); 座1.position.set(0, 0.058, -0.140); 镜组.add(座1);
    var 座2 = new THREE.Mesh(new THREE.BoxGeometry(0.028, 0.036, 0.018), 钢); 座2.position.set(0, 0.058, 0.020); 镜组.add(座2);
    /* 镜体滚花（两圈蓝环，识别色） */
    var 环1 = new THREE.Mesh(new THREE.TorusGeometry(0.025, 0.003, 6, 18), 蓝);
    环1.position.set(0, 0.086, -0.130); 镜组.add(环1);
    镜组.traverse(function (o) { o.userData.scope = 1; });
    g.add(镜组); g.userData._镜组 = 镜组;
  })();

  /* ---------- 拉机柄（拉栓动画要抓它 → animPart） ---------- */
  var 拉杆 = new THREE.Mesh(new THREE.CylinderGeometry(0.006, 0.006, 0.055, 8), 钢);
  拉杆.rotation.z = Math.PI / 2; 拉杆.position.set(0.046, 0.030, 0.030); g.add(拉杆);
  var 拉球 = new THREE.Mesh(new THREE.SphereGeometry(0.013, 10, 8), 蓝暗);
  拉球.position.set(0.074, 0.030, 0.030); g.add(拉球);
  拉杆.userData.animPart = 1; 拉球.userData.animPart = 1;

  /* ---------- 弹匣井 + 扳机组 + 枪托 ---------- */
  bx(0.048, 0.026, 0.070, 身深, 0, -0.058, -0.030);                   // 弹匣井
  bx(0.030, 0.058, 0.036, 身, 0, -0.078, 0.055, -0.22);               // 握把
  bx(0.012, 0.020, 0.030, 钢, 0, -0.040, 0.048);                      // 扳机
  bx(0.040, 0.024, 0.030, 身, 0, -0.016, 0.100);                      // 机匣尾
  bx(0.044, 0.062, 0.160, 身, 0, 0.004, 0.180);                       // 枪托体
  bx(0.046, 0.070, 0.026, 月岩暗, 0, 0.004, 0.262);                   // 托底（月岩色收尾）
  bx(0.020, 0.016, 0.080, 身深, 0, 0.044, 0.170);                     // 托顶贴腮

  /* ---------- 月球挂饰（挂在护木下方，小月球 + 细绳） ---------- */
  (function () {
    var 挂 = new THREE.Group();
    挂.position.set(0.030, -0.052, -0.300);
    /* 绳 */
    var 绳 = new THREE.Mesh(new THREE.CylinderGeometry(0.0016, 0.0016, 0.040, 6), 钢);
    绳.position.set(0, 0.020, 0); 挂.add(绳);
    /* 小月球 */
    var 月 = new THREE.Mesh(new THREE.SphereGeometry(0.024, 16, 12), 月面);
    月.position.set(0, -0.008, 0); 挂.add(月);
    /* 月面坑（两颗） */
    var k1 = new THREE.Mesh(new THREE.SphereGeometry(0.008, 8, 6), 月坑);
    k1.position.set(0.010, -0.002, -0.016); 挂.add(k1);
    var k2 = new THREE.Mesh(new THREE.SphereGeometry(0.005, 8, 6), 月坑);
    k2.position.set(-0.012, -0.014, -0.010); 挂.add(k2);
    /* 小环 */
    var 环 = new THREE.Mesh(new THREE.TorusGeometry(0.006, 0.0015, 6, 10), 钢);
    环.position.set(0, 0.040, 0); 环.rotation.x = Math.PI / 2; 挂.add(环);
    挂.traverse(function (o) { o.raycast = function () { }; });
    g.add(挂); g.userData._挂饰 = 挂;
  })();

  /* ---------- 持枪手 ---------- */
  var 手组 = new THREE.Group();
  if (typeof buildRightHand === 'function')
    buildRightHand(手组, new THREE.Vector3(0.040, -0.070, 0.075), new THREE.Vector3(0.120, -0.075, 0.300));
  g.add(手组); g.userData._右手 = 手组;

  _标静态(g);
  g.userData._引力枪 = 1;
}

/* ==================== 三、弹匣（8 发短直匣，月岩 + 能量条） ==================== */
function _建引力弹匣() {
  var 组 = new THREE.Group(); 组.name = 'magazine';
  var 壳 = new THREE.MeshLambertMaterial({ color: 0xb9c2cc });
  var 壳暗 = new THREE.MeshLambertMaterial({ color: 0x7d8794 });
  var 蓝m = new THREE.MeshBasicMaterial({ color: 0x6ec8ff });
  var 体 = new THREE.Mesh(new THREE.BoxGeometry(0.042, 0.100, 0.048), 壳);
  体.position.set(0, -0.060, -0.018); 组.add(体);
  var 底 = new THREE.Mesh(new THREE.BoxGeometry(0.048, 0.012, 0.054), 壳暗);
  底.position.set(0, -0.114, -0.018); 组.add(底);
  var 顶 = new THREE.Mesh(new THREE.BoxGeometry(0.038, 0.014, 0.044), 壳暗);
  顶.position.set(0, -0.008, -0.018); 组.add(顶);
  /* 侧面能量窗（能看出"还剩几发"的观感，纯装饰） */
  var 窗 = new THREE.Mesh(new THREE.BoxGeometry(0.003, 0.070, 0.010), 蓝m);
  窗.position.set(0.0225, -0.058, -0.018); 组.add(窗);
  var 窗2 = 窗.clone(); 窗2.position.x = -0.0225; 组.add(窗2);
  return 组;
}

/* 包装 buildMagazineGroup：只接管 magType==='gravity' */
(function () {
  if (typeof buildMagazineGroup !== 'function') return;
  var _原建匣 = buildMagazineGroup;
  buildMagazineGroup = function (def, magLv) {
    if (def && def.magType === 'gravity') return _建引力弹匣();
    return _原建匣.apply(this, arguments);
  };
})();

/* ==================== 四、def 注册 ==================== */
BUILTIN_GUNS[GRAVITY_SLOT] = {
  name: 引力枪皮名, icon: '🌑', note: '月球主题 · ' + 引力皮价 + ' 枪皮币',
  引力: true,
  /* 用户口径：伤害 ×4、弹夹 8 发、狙击枪、装弹慢、每枪拉栓 */
  damage: 4.0, magSize: 8, fireRate: 1500, reloadTime: 4200, recoilMul: 1.30,
  range: 170, pellets: 1, spread: 0.0035, auto: false,
  /* 开镜：adsFov 18 ≈ 4.2 倍（75/18），配镜内光学；scopeView 走镜内处理 */
  adsFov: 18, adsSpreadKeep: 0, scopeView: true, reticle: 'gravity',
  inspect: true,
  /* 拉栓：开一枪必须拉一次，拉完才能下一发 */
  boltAction: true, boltTime: 780,
  /* 换弹 / 检视：这两个交给 js/24 按标记走专属动画 */
  reloadAnim: 'gravity', inspectAnim: 'float',
  magType: 'gravity', magPos: { x: 0, y: -0.030, z: -0.055 },
  gripPos: { x: 0.176, y: -0.224, z: -0.430 },
  aimPos: { x: 0, y: -0.100, z: -0.205 },
  lhPos: { x: -0.044, y: -0.098, z: -0.215 },
  枪皮: 引力枪皮名, 皮价: 引力皮价,
  build: _建引力枪
};
引力刷新锁();

/* ==================== 五、拉栓：开一枪必须拉一次 ==================== */
var 引力_上一刻 = 0;
function 引力_是当前枪() {
  try { var d = activeGunDef(); return !!(d && d.引力); } catch (e) { return false; }
}
/* 包装 attack：拉栓中不许开火；真的打出一发 → 进入拉栓 */
(function () {
  if (typeof attack !== 'function') return;
  var _原射击 = attack;
  attack = function () {
    if (引力_是当前枪() && S.boltT > 0) return;          /* 拉栓没拉完，扣扳机没反应 */
    var 弹前 = S.ammo;
    var r = _原射击.apply(this, arguments);
    if (引力_是当前枪() && S.ammo < 弹前) {              /* 确实打出了一发（不是空挂/哑火） */
      var d = activeGunDef();
      S.boltT = Math.max(0.15, ((d && d.boltTime) || 780) / 1000);
      S.boltDur = S.boltT;
      try { if (typeof playBoltPull === 'function') playBoltPull(); } catch (e) { }
    }
    return r;
  };
})();
/* 每帧推进：按剩余时间驱动右手拉机柄 */
(function () {
  if (typeof updatePlayer !== 'function') return;
  var _原更新 = updatePlayer;
  updatePlayer = function () {
    var r = _原更新.apply(this, arguments);
    try { 引力_拉栓Tick(); } catch (e) { }
    return r;
  };
})();
function 引力_拉栓Tick() {
  /* 换掉这把枪（切刀 / 切别的枪）时，拉栓状态立刻作废，否则切回来还卡着 */
  if (!引力_是当前枪()) {
    if (S.boltT > 0 || S.boltWas) {
      S.boltT = 0; S.boltWas = false;
      try { _右手拉栓(0, 0); _拉机柄动(0); } catch (e) { }
    }
    return;
  }
  if (!(S.boltT > 0)) {
    if (S.boltWas) { S.boltWas = false; try { _右手拉栓(0, 0); _拉机柄动(0); } catch (e) { } }
    return;
  }
  var now = performance.now();
  var dt = 引力_上一刻 ? Math.min(0.1, (now - 引力_上一刻) / 1000) : 0.016;
  引力_上一刻 = now;
  S.boltT = Math.max(0, S.boltT - dt);
  var 总 = S.boltDur || 0.78;
  var p = Math.min(1, 1 - S.boltT / 总);                 // 0→1 拉栓进度
  /* 抓柄(0.05~0.85) → 后拉(0.30~0.62 到顶) → 松手(0.62 后回落) */
  var 抓 = (p > 0.05 && p < 0.88) ? 1 : 0;
  var 拉 = 0;
  if (p > 0.28 && p < 0.44) 拉 = (p - 0.28) / 0.16;
  else if (p >= 0.44 && p < 0.58) 拉 = 1;
  else if (p >= 0.58 && p < 0.74) 拉 = 1 - (p - 0.58) / 0.16;
  拉 = Math.max(0, Math.min(1, 拉));
  try { _右手拉栓(抓, 拉); _拉机柄动(拉); } catch (e) { }
  S.boltWas = true;
  if (S.boltT <= 0) { try { if (typeof playBoltSlam === 'function') playBoltSlam(); } catch (e) { } }
}

/* ==================== 七、检视：抛向空中 → 悬浮在正前方旋转 → 接回 ====================
   只在 def.inspectAnim==='float' 时由 js/24 的 _检视推进 调进来（p = 检视进度 0~1）。
   位置用相机局部坐标（weaponGroup 在 recoilPivot 里，原点就是眼睛），
   "玩家的正中间" = x0 / 略高于光轴 / 前伸约 0.6 米。 */
var 引力_检视上次 = 0;
function 引力_检视平滑(t) { t = Math.max(0, Math.min(1, t)); return t * t * (3 - 2 * t); }
function 引力_检视姿态(p, base) {
  var bx = base ? base.x : 0.18, by = base ? base.y : -0.22, bz = base ? base.z : -0.45;
  var x, y, z, rx, ry, rz;
  var 中Y = 0.055, 中Z = -0.60;                 /* 悬浮点：略高于准星、前伸 0.6m */
  if (p < 0.14) {                                /* 抛出：从手心窜上去 */
    var t = 引力_检视平滑(p / 0.14);
    x = bx + (0 - bx) * t;
    y = by + (中Y - by) * t;
    z = bz + (中Z - bz) * t;
    rx = -0.16 * t; ry = 0.30 * t; rz = 0.08 * t;
  } else if (p < 0.22) {                         /* 到顶，开始悬浮 */
    var t2 = 引力_检视平滑((p - 0.14) / 0.08);
    x = 0; y = 中Y + 0.022 * t2; z = 中Z - 0.02 * t2;
    rx = -0.16; ry = 0.30 + 0.45 * t2; rz = 0.08 - 0.08 * t2;
  } else if (p < 0.70) {                         /* 悬浮在正中间旋转（约两圈）＋轻浮 */
    var t3 = (p - 0.22) / 0.48;
    x = Math.sin(t3 * Math.PI) * 0.018;
    y = 中Y + 0.022 + Math.sin(t3 * Math.PI * 2) * 0.020;
    z = 中Z - 0.02;
    rx = -0.14 + Math.sin(t3 * Math.PI * 2) * 0.055;
    ry = 0.75 + t3 * Math.PI * 2.1;
    rz = Math.sin(t3 * Math.PI * 2.5) * 0.10;
  } else if (p < 0.88) {                         /* 落回手心 */
    var t4 = 引力_检视平滑((p - 0.70) / 0.18);
    x = 0 + (bx - 0) * t4;
    y = (中Y + 0.022) + (by - (中Y + 0.022)) * t4;
    z = (中Z - 0.02) + (bz - (中Z - 0.02)) * t4;
    rx = -0.14 * (1 - t4); ry = (0.75 + Math.PI * 2.1) * (1 - t4); rz = 0.10 * (1 - t4);
  } else {                                       /* 收尾：回到正常持握 */
    x = bx; y = by; z = bz; rx = 0; ry = 0; rz = 0;
  }
  weaponGroup.position.set(x, y, z);
  weaponGroup.rotation.set(rx, ry, rz);
  weaponGroup.visible = true;
  /* 枪飞起来的时候，握枪的右手跟着一起走（本来就是枪的部件），
     但托枪的左手和持物手要离开画面 —— 不然半空中会多出两只手。 */
  try {
    if (typeof leftHandAnchor !== 'undefined' && leftHandAnchor && typeof gunLH === 'function') {
      var _lh = gunLH();
      leftHandAnchor.position.set(_lh.x, _lh.y, _lh.z);
      leftHandAnchor.visible = (p < 0.06 || p > 0.96);
    }
    var _rh = weaponGroup.userData._右手;
    if (_rh) _rh.visible = true;
  } catch (e) { }
}

/* ==================== 八、换弹：弹夹从屏幕左侧飘来、左手伸过去接 ====================
   时间轴（a = 换弹进度）：
     0.26~0.40  左手向屏幕左侧伸出去
     0.34       弹夹从画面左外飘入
     0.40~0.50  弹夹飞到左手心
     0.50       交接给左手（attach 保持世界变换，不跳）
     0.48~0.62  手带着弹夹收回枪身
   飞匣挂在相机下（不是 weaponGroup），这样它才能在"枪之外"飞。 */
var 引力_飞匣 = null;
function 引力_飞匣挂载中() { return !!(引力_飞匣 && 引力_飞匣.挂载); }
function 引力_飞匣开始(mag) {
  if (!mag) return false;
  try {
    if (引力_飞匣 && 引力_飞匣.obj && 引力_飞匣.obj.parent) 引力_飞匣.obj.parent.remove(引力_飞匣.obj);
  } catch (e) { }
  引力_飞匣 = { obj: mag, 挂载: true, t: 0, 出发: false };
  /* 起点：画面左侧外（相机局部） */
  camera.add(mag);
  mag.position.set(-0.62, -0.30, -0.80);
  mag.rotation.set(0.35, 0.9, 0.45);
  mag.scale.setScalar(1);
  return true;
}
function 引力_飞匣Tick(a) {
  var F = 引力_飞匣; if (!F || !F.挂载) return;
  /* 换弹结束/被取消 → 飞匣直接清掉，别留在画面上 */
  if (!S.reloading) { 引力_飞匣清理(); return; }
  var o = F.obj; if (!o || !o.parent) { 引力_飞匣 = null; return; }
  /* 0.34 → 0.50 的飞入进度 */
  var t = (a - 0.34) / 0.16;
  t = Math.max(0, Math.min(1, t));
  var k = 引力_检视平滑(t);
  var 起x = -0.62, 起y = -0.30, 起z = -0.80;
  var 止x = -0.265, 止y = -0.285, 止z = -0.545;
  o.position.set(起x + (止x - 起x) * k, 起y + (止y - 起y) * k + Math.sin(k * Math.PI) * 0.035,
    起z + (止z - 起z) * k);
  /* 一路转正（飘过来的时候是歪的，快到手里时已经扶正） */
  o.rotation.set(0.35 * (1 - k) + 0.35 * k * 0.4, 0.9 * (1 - k), 0.45 * (1 - k));
}
function 引力_飞匣交接(anchor, mag) {
  var F = 引力_飞匣; if (!F || !F.挂载) return;
  try {
    anchor.attach(mag);                       /* attach 保持世界变换 → 视觉上不跳 */
    mag.position.set(0.010, -0.026, -0.020);
    mag.rotation.set(0.5, 0, 0.3);
  } catch (e) {
    try { anchor.add(mag); mag.position.set(0.010, -0.026, -0.020); mag.rotation.set(0.5, 0, 0.3); } catch (e2) { }
  }
  F.挂载 = false; F.obj = null;
}
function 引力_飞匣清理() {
  var F = 引力_飞匣; if (!F) return;
  if (F.挂载 && F.obj && F.obj.parent) { try { F.obj.parent.remove(F.obj); } catch (e) { } }
  引力_飞匣 = null;
}
/* 左手向画面左侧伸（由 js/24 在设完普通换弹手位之后调，覆盖成"够过去"） */
function 引力_手偏移(a) {
  if (!引力_是当前枪()) return;
  var t = 0;
  if (a >= 0.26 && a < 0.40) t = (a - 0.26) / 0.14;
  else if (a >= 0.40 && a < 0.48) t = 1;
  else if (a >= 0.48 && a < 0.64) t = 1 - (a - 0.48) / 0.16;
  if (t <= 0) return;
  var k = 引力_检视平滑(t);
  try {
    leftHandAnchor.position.x -= 0.255 * k;      /* 枪局部 -x = 屏幕左侧 */
    leftHandAnchor.position.y += 0.035 * k;
    leftHandAnchor.position.z += 0.075 * k;
    leftHandAnchor.visible = true;
  } catch (e) { }
}

/* ==================== 六、对外 ==================== */
try {
  window.引力枪皮 = {
    名: 引力枪皮名, 槽: GRAVITY_SLOT, 价: 引力皮价,
    已解锁: 引力已解锁, 解锁: 引力解锁, 刷新锁: 引力刷新锁, 购买: 引力购买尝试,
    装备: function () { try { curGun = GRAVITY_SLOT; currentWeapon = WEAPON_GUN; rebuildWeaponModel(); } catch (e) { } }
  };
} catch (e) { }
