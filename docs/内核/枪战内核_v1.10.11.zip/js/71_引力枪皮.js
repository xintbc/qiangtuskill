/* 【1.10.9】月球主题枪皮「引力」（js/71_引力枪皮.js）=====================================
   用户口径（原话拆解）：
     · 引力主题枪皮，弹夹容量 **8**，**伤害 ×4**；
     · 装弹特殊：屏幕**左边飘来一个弹夹**，手伸过去把弹夹拿过来再装到枪上；
     · 枪上有个**月球挂饰**；**前握把是月球那种颜色**（月岩灰）；
     · 检视时玩家把它**抛向空中、悬浮在正中间旋转**；
     · 狙击枪，**每开一枪都要拉一次栓**，拉栓要时间；装弹慢。

   实现分工（照 js/69 万圣枪皮的先例，全部用包装，不改老分片函数体）：
     · 本分片注册 `BUILTIN_GUNS[-3]`（-1 长明 / -2 南瓜 / 2+ 模组枪）；
     · 第一人称模型 = 第三人称模型（js/20 的 _TP复制第一人称 直接复制 def.build）；
     · 弹匣：包装 buildMagazineGroup，magType==='gravity' 时给自己的弹匣；
     · 拉栓：def.boltAction/boltTime，包装 attack（拉栓中不许开火）+ updatePlayer 推进动画；
     · 换弹动画（左侧飞弹夹）与检视（抛空悬浮）在 js/24 里按 def.reloadAnim / inspectAnim 分支。
   ⚠️ 本分片排在 js/70 之后（最后），跨分片调用一律 typeof 守卫。 */

var GRAVITY_SLOT = -3;
var 引力枪皮键 = 'gunGame.gravSkin.v1';
var 引力枪皮名 = '引力';
var 引力皮价 = 200;   /* 重做后价格：比南瓜（250）低一档，用户反馈原 300 不值 */

/* ==================== 一、解锁 / 购买（同万圣枪皮那套） ==================== */
function 引力已解锁() {
  try { return localStorage.getItem(引力枪皮键) === '1'; } catch (e) { return false; }
}
function 引力解锁(静默) {
  try { localStorage.setItem(引力枪皮键, '1'); } catch (e) { }
  引力刷新锁();
  if (!静默) { try { showMsg('🌑 已解锁枪皮「引力」！按 B 打开武器界面装备', '#9fd8ff'); } catch (e) { } }
}
function 引力刷新锁() {
  var d = BUILTIN_GUNS[GRAVITY_SLOT]; if (!d) return;
  var 有 = 引力已解锁();
  d.锁 = !有;
  d.锁提示 = 有 ? '' : '未购买 · 去主菜单「枪械购买」用 ' + 引力皮价 + ' 枪皮币解锁';
}
/* 商店购买钩子（枪皮商店点击时调用，名字与万圣保持一致的口径） */
function 引力购买尝试() {
  if (引力已解锁()) return true;
  try {
    if (typeof 枪皮币 !== 'number' || 枪皮币 < 引力皮价) {
      showMsg('枪皮币不足：需要 ' + 引力皮价 + '（当前 ' + (typeof 枪皮币 === 'number' ? 枪皮币 : 0) + '）', '#ffd166');
      return false;
    }
  } catch (e) { }
  try { 枪皮币 -= 引力皮价; if (typeof 存枪皮币 === 'function') 存枪皮币(); } catch (e) { }
  引力解锁(false);
  return true;
}

/* ==================== 二、模型：狙击枪 + 月球挂饰 + 月岩前握把 ==================== */
function _建引力枪(g) {
  /* 尺寸基准（和纪念枪同一套坐标习惯）：
       枪膛轴线 y=0；握把在 z≈+0.08；枪口 z≈-0.95；全长约 1.02 米。
       瞄镜光轴抬到 y=+0.098 —— 这个高度是"开镜时镜筒内壁刚好框住视野"的经验值。 */
  var 天顶 = Math.PI / 2;

  /* ---- 材质 ---- */
  var 深空 = new THREE.MeshLambertMaterial({ color: 0x232c3a, side: THREE.DoubleSide });   // 枪身主色
  var 深空暗 = new THREE.MeshLambertMaterial({ color: 0x11161f, side: THREE.DoubleSide }); // 暗件/凹槽
  /* 【1.10.11】配色压暗一档：原来月岩灰 0xc3cbd4 在游戏光照下直接烧成纯白，
     整把枪变成"白管子 + 黑机匣"的拼凑感。现在改成中灰偏冷，和深空蓝黑是一个体系里的深浅两级。 */
  /* 【1.10.12】再压一档：预览页光照偏强，0x8b95a2 还是发白。
     月岩灰降到 0x69727e（和深空蓝黑同一体系里的浅一级），枪管降到 0x4f5762，
     整把枪的明度差不超过两级 —— 这才有"一体感"，而不是白管插黑匣。 */
  var 月岩 = new THREE.MeshLambertMaterial({ color: 0x565e69, side: THREE.DoubleSide });   // 月岩灰（前握把/护木/托底）
  var 月岩暗 = new THREE.MeshLambertMaterial({ color: 0x3d444e, side: THREE.DoubleSide }); // 月岩阴影面
  var 钢 = new THREE.MeshLambertMaterial({ color: 0x4f5762, side: THREE.DoubleSide });     // 枪管/小件
  var 钢暗 = new THREE.MeshLambertMaterial({ color: 0x353c45, side: THREE.DoubleSide });
  var 蓝 = new THREE.MeshBasicMaterial({ color: 0x6ec8ff, side: THREE.DoubleSide });       // 引力蓝（发光）
  var 蓝暗 = new THREE.MeshLambertMaterial({ color: 0x2f6f9c, side: THREE.DoubleSide });
  var 月面 = new THREE.MeshLambertMaterial({ color: 0xe4e9ef, side: THREE.DoubleSide });   // 挂饰月球
  var 月坑 = new THREE.MeshLambertMaterial({ color: 0xa3aeba, side: THREE.DoubleSide });
  /* 【1.10.10】镜筒专用单面材质。
     ⚠️ 之前镜筒用了 DoubleSide → 从镜筒里面往外看，**内壁是实心渲染的**，
        开镜时整个视野被一圈黑管壁糊死（用户："只能看见黑黑的东西"）。
        圆柱用默认的 FrontSide：外壁正常、内壁背面剔除 → 从里往外看是通透的。 */
  var 镜筒 = new THREE.MeshLambertMaterial({ color: 0x1d2534 });
  var 镜筒暗 = new THREE.MeshLambertMaterial({ color: 0x11161f });
  var 镜钢 = new THREE.MeshLambertMaterial({ color: 0x9ca6b4 });

  function bx(w, h, d, m, x, y, z, rx, ry, rz) {
    var o = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);
    o.position.set(x || 0, y || 0, z || 0);
    if (rx) o.rotation.x = rx; if (ry) o.rotation.y = ry; if (rz) o.rotation.z = rz;
    g.add(o); return o;
  }
  function cy(rt, rb, len, m, x, y, z, rx, seg) {
    var o = new THREE.Mesh(new THREE.CylinderGeometry(rt, rb, len, seg || 16), m);
    o.position.set(x || 0, y || 0, z || 0);
    o.rotation.x = (rx === undefined ? 天顶 : rx);
    g.add(o); return o;
  }
  function 环(R, 管, m, x, y, z, seg, rx) {
    var o = new THREE.Mesh(new THREE.TorusGeometry(R, 管, 8, seg || 20), m);
    o.position.set(x, y, z); o.rotation.x = (rx === undefined ? 天顶 : rx);
    g.add(o); return o;
  }

  /* ================= 一、机匣 ================= */
  /* 上机匣（分三段：前段略细、中段主体、后段接枪托） */
  bx(0.062, 0.058, 0.090, 深空, 0, 0.020, -0.150);            // 上机匣·前
  bx(0.068, 0.066, 0.190, 深空, 0, 0.020, -0.010);            // 上机匣·中
  bx(0.060, 0.056, 0.070, 深空, 0, 0.018, 0.118);             // 上机匣·后
  /* 下机匣 */
  bx(0.062, 0.048, 0.250, 深空, 0, -0.026, -0.020);
  bx(0.056, 0.034, 0.070, 深空, 0, -0.024, 0.108);            // 下机匣后段（扳机组）
  /* 机匣分界线（深槽） */
  bx(0.064, 0.006, 0.300, 深空暗, 0, -0.003, -0.020);
  bx(0.058, 0.004, 0.300, 深空暗, 0, 0.048, -0.010);          // 上沿压线
  /* 两侧能量槽（引力识别色，两段：前短后长） */
  bx(0.003, 0.008, 0.120, 蓝, -0.0322, 0.022, -0.090);
  bx(0.003, 0.008, 0.120, 蓝, 0.0322, 0.022, -0.090);
  bx(0.003, 0.006, 0.060, 蓝暗, -0.0322, 0.022, 0.062);
  bx(0.003, 0.006, 0.060, 蓝暗, 0.0322, 0.022, 0.062);
  /* 抛壳窗（真凹槽：上下左右四边框，中间空） */
  bx(0.006, 0.004, 0.070, 深空暗, 0.0316, 0.036, 0.008);
  bx(0.006, 0.004, 0.070, 深空暗, 0.0316, 0.008, 0.008);
  bx(0.006, 0.032, 0.004, 深空暗, 0.0316, 0.022, 0.042);
  bx(0.006, 0.032, 0.004, 深空暗, 0.0316, 0.022, -0.026);
  /* 销钉 / 螺丝（左右各两颗 + 顶部一颗） */
  cy(0.0035, 0.0035, 0.066, 钢暗, 0, -0.012, -0.080, 天顶, 8);
  cy(0.0035, 0.0035, 0.066, 钢暗, 0, -0.012, 0.070, 天顶, 8);
  cy(0.0025, 0.0025, 0.010, 钢, -0.030, -0.012, -0.080, 0, 8);
  cy(0.0025, 0.0025, 0.010, 钢, 0.030, -0.012, -0.080, 0, 8);
  /* 顶部导轨（12 齿，狙击枪标配） */
  bx(0.026, 0.006, 0.300, 深空暗, 0, 0.0515, -0.030);
  (function () {
    for (var i = 0; i < 12; i++) {
      bx(0.030, 0.005, 0.008, 深空, 0, 0.0565, -0.166 + i * 0.024);
    }
  })();

  /* ================= 二、枪管 ================= */
  /* 【1.10.11】枪管原来 0.56 米长、半径 13mm，预览图里就是一根刺眼的白管子。
     缩到 0.40 米、加粗到 15mm，长度比例回到"重狙但不是狙击炮"。 */
  cy(0.019, 0.019, 0.230, 钢, 0, 0.020, -0.300, 天顶, 20);       // 粗管（护木内）
  cy(0.015, 0.015, 0.300, 钢, 0, 0.020, -0.565, 天顶, 20);       // 外露细管
  cy(0.018, 0.018, 0.028, 钢暗, 0, 0.020, -0.420, 天顶, 18);     // 管箍
  /* 导气 / 枪管座 */
  bx(0.046, 0.034, 0.040, 深空, 0, 0.020, -0.250);
  bx(0.030, 0.014, 0.018, 钢暗, 0, 0.043, -0.250);
  /* 制退器：主体 + 三道开槽 + 前端面 + 蓝色能量环 */
  cy(0.021, 0.021, 0.072, 深空暗, 0, 0.020, -0.752, 天顶, 18);
  (function () {
    for (var i = 0; i < 3; i++) {
      bx(0.044, 0.006, 0.010, 深空, 0, 0.020, -0.730 - i * 0.019);
    }
    bx(0.040, 0.010, 0.004, 钢暗, 0, 0.020, -0.786);
  })();
  环(0.023, 0.0035, 蓝, 0, 0.020, -0.716, 18, 0);
  /* 枪口内孔（黑） */
  cy(0.012, 0.012, 0.004, 深空暗, 0, 0.020, -0.789, 天顶, 14);

  /* ================= 三、护木（月岩灰）+ 散热孔 + 前握把 ================= */
  bx(0.056, 0.048, 0.230, 月岩, 0, 0.006, -0.320);               // 护木主体（往前多包 4cm，盖住枪管根部）
  bx(0.050, 0.040, 0.040, 月岩暗, 0, 0.006, -0.448);             // 护木前端收口
  bx(0.058, 0.008, 0.190, 月岩暗, 0, 0.033, -0.300);             // 护木上沿
  bx(0.058, 0.006, 0.190, 月岩暗, 0, -0.020, -0.300);            // 护木下沿
  /* 侧面散热孔（每侧 3 个，真孔位用暗色框表示） */
  (function () {
    for (var i = 0; i < 3; i++) {
      bx(0.004, 0.020, 0.026, 深空暗, 0.0292, 0.006, -0.250 - i * 0.048);
      bx(0.004, 0.020, 0.026, 深空暗, -0.0292, 0.006, -0.250 - i * 0.048);
    }
  })();
  /* 护木顶部短导轨 */
  bx(0.024, 0.005, 0.120, 深空暗, 0, 0.0395, -0.300);
  /* ---- 前握把（用户点名：月球那种颜色）---- */
  bx(0.034, 0.120, 0.038, 月岩, 0, -0.070, -0.270, 0.14);        // 把身
  bx(0.038, 0.012, 0.044, 月岩暗, 0, -0.128, -0.264, 0.14);      // 底盖
  bx(0.036, 0.010, 0.040, 月岩暗, 0, -0.012, -0.276, 0.14);      // 上箍
  /* 三道指槽 */
  (function () {
    for (var i = 0; i < 3; i++) {
      bx(0.039, 0.008, 0.006, 月岩暗, 0, -0.036 - i * 0.030, -0.2525 - i * 0.0042, 0.14);
    }
  })();
  /* 把身上的月面坑（4 个深浅不一的小凹） */
  (function () {
    var 坑 = [[-0.008, -0.030, 0.0072], [0.009, -0.052, 0.0055], [-0.005, -0.084, 0.0064], [0.007, -0.104, 0.0042]];
    for (var i = 0; i < 坑.length; i++) {
      var d = new THREE.Mesh(new THREE.CylinderGeometry(坑[i][2], 坑[i][2], 0.003, 10), 月岩暗);
      d.rotation.x = 天顶 + 0.14;
      d.position.set(坑[i][0], 坑[i][1], -0.2525);
      g.add(d);
    }
  })();

  /* ================= 四、两脚架（狙击枪骨架感） ================= */
  bx(0.032, 0.012, 0.034, 钢暗, 0, -0.032, -0.430);
  /* 【1.10.12】rx 必须是**负**的才朝前下方斜撑：绕 X 转 +1.15 时长轴倒向后方，
     上一版脚垫按"+1.15"的心算放，结果离杆端 7cm —— 那两个小白块就是这么悬空的。
     rx=-1.15 → 杆端落在 (x, -0.132, -0.492)，脚垫贴在那里。 */
  bx(0.009, 0.009, 0.110, 钢暗, -0.020, -0.082, -0.470, -1.15);  // 左脚（向前斜撑）
  bx(0.009, 0.009, 0.110, 钢暗, 0.020, -0.082, -0.470, -1.15);   // 右脚
  bx(0.016, 0.009, 0.018, 钢, -0.020, -0.132, -0.492);           // 脚垫（贴住杆端）
  bx(0.016, 0.009, 0.018, 钢, 0.020, -0.132, -0.492);

  /* ================= 五、瞄镜（不打 scope 标记！开镜时要留着） =================
     ⚠️ 上一版把整组打上 userData.scope=1，js/24 的「开镜功能件同步」会在开镜时
        把这件藏起来 → 开镜后只剩一根光枪管，什么镜都没有。教训记在这。
     光轴 y=+0.098：和纪念枪同一个经验高度，开镜时镜筒内壁刚好框住视野。 */
  var 轴Y = 0.098;
  var _镜件起 = g.children.length;
  (function () {
    /* 主镜管 */
    cy(0.026, 0.026, 0.250, 镜筒, 0, 轴Y, -0.055, 天顶, 22);
    /* 物镜端（前喇叭口）+ 物镜环 + 遮光罩 */
    /* 【1.10.10】物镜口径 0.034→0.042：开镜时限制视野的是"物镜半径/眼到物镜距离"，
       0.034@0.533m 只有 3.6° 半角，比纪念枪（5.1°）还窄一圈。放到 0.042 ≈ 4.5°，接近纪念枪。 */
    cy(0.048, 0.026, 0.085, 镜筒暗, 0, 轴Y, -0.213, 天顶, 26);
    环(0.0485, 0.0040, 镜钢, 0, 轴Y, -0.252, 26, 天顶);
    cy(0.052, 0.050, 0.038, 镜筒, 0, 轴Y, -0.276, 天顶, 26);
    /* ---- 三片镜片：物镜 / 中间 / 目镜 ----
       ⚠️ 上一版物镜玻璃 opacity 0.35，开镜时那是一层真实半透明挡片。
          现在全部压到 0.055、depthWrite:false —— 只剩一点点镀膜反光，透过去一丝不挡。
       每片外面套一道极细的金属圈（0.0015 厚），让人看得出"这里有一片镜片"。 */
    var 玻材 = new THREE.MeshBasicMaterial({
      color: 0x9fd8ff, transparent: true, opacity: 0.055,
      depthWrite: false, side: THREE.DoubleSide
    });
    var 圈材 = new THREE.MeshBasicMaterial({ color: 0x7fb6d8, transparent: true, opacity: 0.55, depthWrite: false });
    /* 物镜片（大） */
    cy(0.038, 0.038, 0.0022, 玻材, 0, 轴Y, -0.286, 天顶, 22);
    var 圈1 = new THREE.Mesh(new THREE.RingGeometry(0.0372, 0.0405, 26, 1), 圈材);
    圈1.position.set(0, 轴Y, -0.286); g.add(圈1);
    /* 中间片（在镜筒中段，正对仰角旋钮下方） */
    cy(0.0255, 0.0255, 0.0018, 玻材, 0, 轴Y, -0.105, 天顶, 20);
    var 圈2 = new THREE.Mesh(new THREE.RingGeometry(0.0248, 0.0268, 22, 1), 圈材);
    圈2.position.set(0, 轴Y, -0.105); g.add(圈2);
    /* 目镜片（小，离眼睛最近） */
    cy(0.0245, 0.0245, 0.0018, 玻材, 0, 轴Y, 0.116, 天顶, 20);
    var 圈3 = new THREE.Mesh(new THREE.RingGeometry(0.0238, 0.0258, 22, 1), 圈材);
    圈3.position.set(0, 轴Y, 0.116); g.add(圈3);
    /* 目镜端 */
    cy(0.028, 0.024, 0.060, 镜筒暗, 0, 轴Y, 0.088, 天顶, 22);
    环(0.0285, 0.0032, 镜钢, 0, 轴Y, 0.118, 22, 天顶);
    /* 目镜橡胶罩（外圈） */
    环(0.031, 0.006, 深空暗, 0, 轴Y, 0.120, 20, 天顶);
    /* 调节旋钮：顶部一颗（仰角）、右侧一颗（风偏） */
    cy(0.010, 0.010, 0.014, 钢暗, 0, 轴Y + 0.028, -0.060, 0, 12);
    cy(0.009, 0.009, 0.012, 钢暗, 0.030, 轴Y, -0.060, 0, 12);
    /* 镜体两道蓝环（识别色） */
    环(0.0265, 0.0028, 蓝, 0, 轴Y, -0.130, 22, 天顶);
    环(0.0265, 0.0028, 蓝, 0, 轴Y, 0.040, 22, 天顶);
    /* 两个镜座：环形抱箍 + 下方短桥 + 压导轨的夹具 */
    var 座Z = [-0.160, -0.010];
    for (var i = 0; i < 2; i++) {
      环(0.0285, 0.0034, 深空暗, 0, 轴Y, 座Z[i], 20, 天顶);
      var 桥顶 = 轴Y - 0.0285 + 0.002, 桥底 = 0.0565;
      var 桥高 = Math.max(0.006, 桥顶 - 桥底);
      bx(0.030, 桥高, 0.024, 深空, 0, 桥底 + 桥高 / 2, 座Z[i]);
      bx(0.034, 0.010, 0.028, 深空暗, 0, 0.0615, 座Z[i]);
      bx(0.036, 0.0026, 0.030, 钢, 0, 0.0558, 座Z[i]);
    }
  })();
  /* 【1.10.11】瞄镜整体缩小 15% 并压低：预览图里那个镜筒比机匣还粗，像架了一台望远镜。
     把所有镜件收进一个 Group 再统一 scale/position，比逐个改十几个坐标安全。 */
  (function () {
    var 镜组 = new THREE.Group(); var 移 = [];
    for (var i = _镜件起; i < g.children.length; i++) 移.push(g.children[i]);
    for (var j = 0; j < 移.length; j++) { g.remove(移[j]); 镜组.add(移[j]); }
    镜组.scale.setScalar(0.80);
    镜组.position.set(0, -0.012, 0.030);
    g.add(镜组);
    g.userData._镜组 = 镜组;
  })();
  /* 【1.10.11】不再整组隐藏瞄具（用户："非要隐藏它那么大一个瞄准镜，看着不别扭吗"）。
     中空靠两件事保证：①镜筒用单面材质 → 从里面往外看，背面剔除、内壁根本不画；
     ②镜片全部是极低透明度 + depthWrite:false → 只留一点反光，不挡任何东西。
     这样开镜时你看到的是"透过镜筒看出去"的放大画面，镜子本身还在枪上。 */

  /* ================= 六、扳机组 / 握把 / 枪托 ================= */
  /* 弹匣井 */
  /* 【1.10.12】弹匣井加长加深：原来只到 y=-0.070，弹匣上沿是 -0.006，
     中间一段是空的 —— 侧面看像"弹匣贴在机匣底下"。现在井壁压到 -0.086，把弹匣咬住。 */
  bx(0.050, 0.046, 0.074, 深空暗, 0, -0.048, -0.055);
  bx(0.054, 0.008, 0.078, 深空, 0, -0.086, -0.055);
  bx(0.006, 0.040, 0.070, 深空, -0.026, -0.048, -0.055);         // 井壁左
  bx(0.006, 0.040, 0.070, 深空, 0.026, -0.048, -0.055);          // 井壁右
  /* 手枪握把（深空色，带指槽） */
  bx(0.032, 0.100, 0.040, 深空, 0, -0.078, 0.060, -0.24);
  bx(0.034, 0.010, 0.044, 深空暗, 0, -0.126, 0.084, -0.24);
  bx(0.033, 0.006, 0.006, 深空暗, 0, -0.058, 0.039, -0.24);
  bx(0.033, 0.006, 0.006, 深空暗, 0, -0.080, 0.046, -0.24);
  /* 扳机护圈（三块拼成 U 形）+ 扳机 + 保险 */
  bx(0.008, 0.040, 0.006, 深空暗, 0, -0.056, 0.028);
  bx(0.008, 0.006, 0.052, 深空暗, 0, -0.076, 0.002);
  bx(0.008, 0.034, 0.006, 深空暗, 0, -0.060, -0.024);
  bx(0.010, 0.026, 0.008, 钢, 0, -0.048, 0.010, 0.22);           // 扳机
  bx(0.008, 0.010, 0.024, 钢暗, 0.024, -0.014, 0.052);           // 保险杆
  /* 枪托：托体 + 贴腮 + 托底 + 调节钮 + 背带环 */
  /* 【1.10.12】枪托原来是一个大方块。现在分四段：托身 → 托颈 → 托腮 → 托底橡胶垫，
     并在托身上加一道斜切，侧影有"狙击枪托"的收腰。 */
  bx(0.048, 0.060, 0.100, 深空, 0, 0.006, 0.176);                // 托身
  bx(0.046, 0.050, 0.058, 深空, 0, 0.000, 0.246);                // 托颈
  bx(0.050, 0.056, 0.040, 深空暗, 0, 0.002, 0.292);              // 托体加厚段
  bx(0.052, 0.078, 0.020, 月岩暗, 0, 0.004, 0.320);              // 托底（月岩色）
  bx(0.054, 0.014, 0.010, 钢暗, 0, -0.030, 0.326);               // 托底橡胶垫
  bx(0.022, 0.016, 0.092, 深空暗, 0, 0.050, 0.196);              // 贴腮板
  bx(0.024, 0.006, 0.094, 月岩暗, 0, 0.059, 0.196);              // 贴腮上沿（月岩色）
  cy(0.006, 0.006, 0.012, 钢暗, 0.028, 0.008, 0.286, 0, 10);     // 托长调节钮
  环(0.008, 0.002, 钢, -0.026, -0.010, 0.290, 12, 0);            // 背带环

  /* ================= 七、月球挂饰（明显可见，带环形山） ================= */
  (function () {
    var 挂 = new THREE.Group();
    /* 【1.10.12】原来挂在 z=-0.318，和前握把(z=-0.270)、两脚架(z=-0.360)挤在一段里，
       侧面看是"护木下面挂了三个东西"。现在挪到护木中段 z=-0.185、并挂到右侧外沿 x=0.052。 */
    /* 【1.10.12】刚才挂到 x=0.052 的右侧外沿，从斜前视角完全被护木挡住 —— 用户要的是"枪上有月球挂饰"，
       必须一眼能看见。收回护木正下方 x=0.028，z=-0.180（前握把在 -0.270，不打架）。 */
    挂.position.set(0.028, -0.052, -0.180);
    /* 挂环 + 绳 */
    var 环1 = new THREE.Mesh(new THREE.TorusGeometry(0.0065, 0.0016, 6, 12), 钢);
    环1.rotation.x = 天顶; 挂.add(环1);
    var 绳 = new THREE.Mesh(new THREE.CylinderGeometry(0.0018, 0.0018, 0.042, 6), 钢暗);
    绳.position.set(0, 0.022, 0); 挂.add(绳);
    /* 小月球 */
    var 月 = new THREE.Mesh(new THREE.SphereGeometry(0.030, 18, 14), 月面);
    月.position.set(0, -0.012, 0); 挂.add(月);
    /* 环形山（5 个，深浅不一，正面朝外） */
    var 坑表 = [[0.011, 0.002, -0.021, 0.0090], [-0.010, -0.008, -0.021, 0.0062],
    [0.002, -0.020, -0.016, 0.0050], [0.016, -0.016, -0.014, 0.0042],
    [-0.014, 0.008, -0.018, 0.0038]];
    for (var i = 0; i < 坑表.length; i++) {
      var k = new THREE.Mesh(new THREE.SphereGeometry(坑表[i][3], 8, 6), 月坑);
      k.position.set(0 + 坑表[i][0], -0.012 + 坑表[i][1], 坑表[i][2]);
      挂.add(k);
    }
    /* 挂饰上的引力蓝小点（和枪身呼应） */
    var 点 = new THREE.Mesh(new THREE.SphereGeometry(0.0022, 6, 5), 蓝);
    点.position.set(-0.012, 0.003, -0.023); 挂.add(点);
    挂.traverse(function (o) { o.raycast = function () { }; });
    g.add(挂); g.userData._挂饰 = 挂;
  })();

  /* ================= 八、持枪手 ================= */
  var 手组 = new THREE.Group();
  if (typeof buildRightHand === 'function')
    buildRightHand(手组, new THREE.Vector3(0.038, -0.066, 0.066), new THREE.Vector3(0.120, -0.072, 0.300));
  g.add(手组); g.userData._右手 = 手组;

  _标静态(g);
  g.userData._引力枪 = 1;
}

/* ==================== 三、弹匣（8 发短直匣，月岩 + 能量条） ==================== */
function _建引力弹匣() {
  /* 【1.10.10】用户："放了三块方块就说自己是弹夹" —— 重做。
     结构照真弹匣：外壳四面（前后+左右，中间是真空腔）+ 8 发可见子弹 + 托弹板 + 底板 + 卡榫 + 侧面观察窗。 */
  var 组 = new THREE.Group(); 组.name = 'magazine';
  var 壳 = new THREE.MeshLambertMaterial({ color: 0xc3cbd4 });        // 月岩灰
  var 壳暗 = new THREE.MeshLambertMaterial({ color: 0x8d97a3 });
  var 壳深 = new THREE.MeshLambertMaterial({ color: 0x5d6672 });
  var 蓝m = new THREE.MeshBasicMaterial({ color: 0x6ec8ff });
  var 铜 = new THREE.MeshLambertMaterial({ color: 0xb08a4a });        // 弹壳
  var 铅 = new THREE.MeshLambertMaterial({ color: 0x9aa4b2 });        // 弹头

  var 宽 = 0.044, 高 = 0.112, 厚 = 0.050;
  /* 外壳四面（左右侧板 + 前后挡板），中间留空腔放子弹 */
  var 左 = new THREE.Mesh(new THREE.BoxGeometry(0.004, 高, 厚), 壳); 左.position.set(-宽 / 2 + 0.002, -0.062, -0.018); 组.add(左);
  var 右 = new THREE.Mesh(new THREE.BoxGeometry(0.004, 高, 厚), 壳); 右.position.set(宽 / 2 - 0.002, -0.062, -0.018); 组.add(右);
  var 前 = new THREE.Mesh(new THREE.BoxGeometry(宽, 高, 0.004), 壳暗); 前.position.set(0, -0.062, -0.018 - 厚 / 2 + 0.002); 组.add(前);
  var 后 = new THREE.Mesh(new THREE.BoxGeometry(宽, 高, 0.004), 壳暗); 后.position.set(0, -0.062, -0.018 + 厚 / 2 - 0.002); 组.add(后);
  /* 顶部喂弹口（缩口，接机匣） */
  var 口 = new THREE.Mesh(new THREE.BoxGeometry(宽 - 0.008, 0.014, 厚 - 0.010), 壳深);
  口.position.set(0, -0.004, -0.018); 组.add(口);
  /* 底板 + 底沿凸台 */
  var 底 = new THREE.Mesh(new THREE.BoxGeometry(宽 + 0.006, 0.012, 厚 + 0.006), 壳深);
  底.position.set(0, -0.122, -0.018); 组.add(底);
  var 底沿 = new THREE.Mesh(new THREE.BoxGeometry(宽 + 0.002, 0.005, 厚 + 0.002), 壳暗);
  底沿.position.set(0, -0.116, -0.018); 组.add(底沿);
  /* 托弹板（弹簧顶板，浅色一片） */
  var 托 = new THREE.Mesh(new THREE.BoxGeometry(宽 - 0.012, 0.006, 厚 - 0.012), 壳暗);
  托.position.set(0, -0.026, -0.018); 组.add(托);

  /* 8 发子弹：双排交错（能看见最上面两发 + 侧面窗里的排布） */
  (function () {
    var 弹R = 0.0042, 壳长 = 0.026;
    for (var i = 0; i < 8; i++) {
      var 左排 = (i % 2 === 0);
      var x = 左排 ? -0.009 : 0.009;
      var y = -0.040 - i * 0.0105;
      var 壳m = new THREE.Mesh(new THREE.CylinderGeometry(弹R, 弹R, 壳长, 8), 铜);
      壳m.position.set(x, y, -0.018); 组.add(壳m);
      var 头 = new THREE.Mesh(new THREE.ConeGeometry(弹R * 0.92, 0.012, 8), 铅);
      头.position.set(x, y + 壳长 / 2 + 0.005, -0.018); 组.add(头);
    }
  })();
  /* 侧面观察窗（左右各一道细长蓝窗，能透出里面的子弹轮廓） */
  var 窗L = new THREE.Mesh(new THREE.BoxGeometry(0.0018, 0.070, 0.012), 蓝m);
  窗L.position.set(-宽 / 2 + 0.0004, -0.066, -0.018); 组.add(窗L);
  var 窗R = 窗L.clone(); 窗R.position.x = 宽 / 2 - 0.0004; 组.add(窗R);
  /* 卡榫（侧面凸起的小块，插进枪的那一下能看见它咬合） */
  var 榫 = new THREE.Mesh(new THREE.BoxGeometry(0.006, 0.008, 0.014), 壳深);
  榫.position.set(-宽 / 2 - 0.002, -0.030, -0.018); 组.add(榫);
  /* 底部铭牌位（一道深色横条，不加文字） */
  var 条 = new THREE.Mesh(new THREE.BoxGeometry(宽 - 0.010, 0.004, 0.003), 壳深);
  条.position.set(0, -0.104, -0.018 - 厚 / 2 + 0.001); 组.add(条);
  return 组;
}

/* 包装 buildMagazineGroup：只接管 magType==='gravity' */
(function () {
  if (typeof buildMagazineGroup !== 'function') return;
  var _原建匣 = buildMagazineGroup;
  buildMagazineGroup = function (def, magLv) {
    if (def && def.magType === 'gravity') return _建引力弹匣();
    return _原建匣.apply(this, arguments);
  };
})();

/* ==================== 四、def 注册 ==================== */
BUILTIN_GUNS[GRAVITY_SLOT] = {
  name: 引力枪皮名, icon: '🌑', note: '月球主题 · 高倍狙 · ' + 引力皮价 + ' 枪皮币',
  引力: true,
  /* 用户口径：伤害 ×4、弹夹 8 发、狙击枪、装弹慢、每枪拉栓 */
  damage: 4.0, magSize: 8, fireRate: 1500, reloadTime: 4200, recoilMul: 1.30,
  /* 腰射散布 0.085（≈6°）—— 狙击枪不开镜本来就该打不中（用户："不开镜根本就玩不了的那一种"）。
     开镜靠 adsSpreadKeep:0 把散布清成 0，一枪一个准。
     ⚠️ 上一版写 0.0035，比步枪（0.016）还准，等于腰射也能当连狙用。 */
  range: 170, pellets: 1, spread: 0.085, auto: false,
  /* 开镜：adsFov 24 ≈ 3.1 倍（和纪念枪同档）。
     ⚠️ 上一版 18（4.2 倍）视野窄到只剩一根枪管，被用户点名"开镜是啥东西"。
     ⚠️ 上一版还把瞄镜整组打了 userData.scope → 开镜瞬间镜子被隐藏，更没法看。
     现在瞄镜是真镜筒（不标 scope），aimPos 把目镜推到眼前 0.135 米，镜筒内壁自己框视野。 */
  /* 【1.10.11】倍率 3.1 → **4.2 倍**（用户："把那个放大倍率调大"）。
     scopeView 仍关掉：开镜不做镜内圆遮罩 —— 目镜孔径半角（11.7°）比屏幕半角（8.9°）大，
     遮罩本来就盖不到屏幕里；而一旦打开，它要求一套镜内分划几何，做不齐反而添乱。
     现在的观感就是"透过中空镜筒看出去"，干净且不挡。 */
  adsFov: 18, adsSpreadKeep: 0, scopeView: false, reticle: 'gravity',
  inspect: true,
  /* 拉栓：开一枪必须拉一次，拉完才能下一发 */
  boltAction: true, boltTime: 780,
  /* 换弹 / 检视：这两个交给 js/24 按标记走专属动画 */
  reloadAnim: 'gravity', inspectAnim: 'float',
  magType: 'gravity', magPos: { x: 0, y: -0.014, z: -0.055 },   /* 上提 1.6cm：原来顶上留着一道缝，像没插到底 */
  gripPos: { x: 0.176, y: -0.224, z: -0.430 },
  /* 【1.10.11】瞄镜组 scale 0.85 + 下移 1.2cm 之后，光轴从 y=0.098 变成 0.071、
     目镜后沿从 z=+0.120 变成 +0.112 → aimPos 跟着重算：
       y=-0.071 把光轴压到眼睛高度；z=-(0.112+0.135)=-0.247 让目镜离眼 13.5cm。 */
  aimPos: { x: 0, y: -0.066, z: -0.261 },
  lhPos: { x: -0.044, y: -0.098, z: -0.215 },
  枪皮: 引力枪皮名, 皮价: 引力皮价,
  build: _建引力枪
};
引力刷新锁();

/* ==================== 五、拉栓：开一枪必须拉一次 ==================== */
var 引力_上一刻 = 0;
function 引力_是当前枪() {
  try { var d = activeGunDef(); return !!(d && d.引力); } catch (e) { return false; }
}
/* 包装 attack：拉栓中不许开火；真的打出一发 → 进入拉栓 */
(function () {
  if (typeof attack !== 'function') return;
  var _原射击 = attack;
  attack = function () {
    if (引力_是当前枪() && S.boltT > 0) return;          /* 拉栓没拉完，扣扳机没反应 */
    var 弹前 = S.ammo;
    var r = _原射击.apply(this, arguments);
    if (引力_是当前枪() && S.ammo < 弹前) {              /* 确实打出了一发（不是空挂/哑火） */
      var d = activeGunDef();
      S.boltT = Math.max(0.15, ((d && d.boltTime) || 780) / 1000);
      S.boltDur = S.boltT;
      try { if (typeof playBoltPull === 'function') playBoltPull(); } catch (e) { }
    }
    return r;
  };
})();
/* 每帧推进：按剩余时间驱动右手拉机柄 */
(function () {
  if (typeof updatePlayer !== 'function') return;
  var _原更新 = updatePlayer;
  updatePlayer = function () {
    var r = _原更新.apply(this, arguments);
    try { 引力_拉栓Tick(); } catch (e) { }
    return r;
  };
})();
function 引力_拉栓Tick() {
  /* 换掉这把枪（切刀 / 切别的枪）时，拉栓状态立刻作废，否则切回来还卡着 */
  if (!引力_是当前枪()) {
    if (S.boltT > 0 || S.boltWas) {
      S.boltT = 0; S.boltWas = false;
      try { _右手拉栓(0, 0); _拉机柄动(0); } catch (e) { }
    }
    return;
  }
  if (!(S.boltT > 0)) {
    if (S.boltWas) { S.boltWas = false; try { _右手拉栓(0, 0); _拉机柄动(0); } catch (e) { } }
    return;
  }
  var now = performance.now();
  var dt = 引力_上一刻 ? Math.min(0.1, (now - 引力_上一刻) / 1000) : 0.016;
  引力_上一刻 = now;
  S.boltT = Math.max(0, S.boltT - dt);
  var 总 = S.boltDur || 0.78;
  var p = Math.min(1, 1 - S.boltT / 总);                 // 0→1 拉栓进度
  /* 抓柄(0.05~0.85) → 后拉(0.30~0.62 到顶) → 松手(0.62 后回落) */
  var 抓 = (p > 0.05 && p < 0.88) ? 1 : 0;
  var 拉 = 0;
  if (p > 0.28 && p < 0.44) 拉 = (p - 0.28) / 0.16;
  else if (p >= 0.44 && p < 0.58) 拉 = 1;
  else if (p >= 0.58 && p < 0.74) 拉 = 1 - (p - 0.58) / 0.16;
  拉 = Math.max(0, Math.min(1, 拉));
  try { _右手拉栓(抓, 拉); _拉机柄动(拉); } catch (e) { }
  S.boltWas = true;
  if (S.boltT <= 0) { try { if (typeof playBoltSlam === 'function') playBoltSlam(); } catch (e) { } }
}

/* ==================== 七、检视：抛向空中 → 悬浮在正前方旋转 → 接回 ====================
   只在 def.inspectAnim==='float' 时由 js/24 的 _检视推进 调进来（p = 检视进度 0~1）。
   位置用相机局部坐标（weaponGroup 在 recoilPivot 里，原点就是眼睛），
   "玩家的正中间" = x0 / 略高于光轴 / 前伸约 0.6 米。 */
var 引力_检视上次 = 0;
function 引力_检视平滑(t) { t = Math.max(0, Math.min(1, t)); return t * t * (3 - 2 * t); }
function 引力_检视姿态(p, base) {
  var bx = base ? base.x : 0.18, by = base ? base.y : -0.22, bz = base ? base.z : -0.45;
  var x, y, z, rx, ry, rz;
  /* 【1.10.10】悬浮点往外挪到 0.82 米 —— 枪全长 1.02 米，0.6 米处会顶到脸、只看得见机匣。
     旋转从 2.1 圈降到 1 圈（用户："转的那么快"）。 */
  var 中Y = 0.048, 中Z = -0.82;
  if (p < 0.14) {                                /* 抛出：从手心窜上去 */
    var t = 引力_检视平滑(p / 0.14);
    x = bx + (0 - bx) * t;
    y = by + (中Y - by) * t;
    z = bz + (中Z - bz) * t;
    rx = -0.16 * t; ry = 0.30 * t; rz = 0.08 * t;
  } else if (p < 0.22) {                         /* 到顶，开始悬浮 */
    var t2 = 引力_检视平滑((p - 0.14) / 0.08);
    x = 0; y = 中Y + 0.022 * t2; z = 中Z - 0.02 * t2;
    rx = -0.16; ry = 0.30 + 0.45 * t2; rz = 0.08 - 0.08 * t2;
  } else if (p < 0.70) {                         /* 悬浮在正中间旋转（一圈）＋轻浮 */
    var t3 = (p - 0.22) / 0.48;
    x = Math.sin(t3 * Math.PI) * 0.018;
    y = 中Y + 0.022 + Math.sin(t3 * Math.PI * 2) * 0.020;
    z = 中Z - 0.02;
    rx = -0.14 + Math.sin(t3 * Math.PI * 2) * 0.055;
    ry = 0.55 + t3 * Math.PI * 2.0;          /* 整段转一圈（原 2.1 圈） */
    rz = Math.sin(t3 * Math.PI * 2.5) * 0.10;
  } else if (p < 0.88) {                         /* 落回手心 */
    var t4 = 引力_检视平滑((p - 0.70) / 0.18);
    x = 0 + (bx - 0) * t4;
    y = (中Y + 0.022) + (by - (中Y + 0.022)) * t4;
    z = (中Z - 0.02) + (bz - (中Z - 0.02)) * t4;
    rx = -0.14 * (1 - t4); ry = (0.75 + Math.PI * 2.1) * (1 - t4); rz = 0.10 * (1 - t4);
  } else {                                       /* 收尾：回到正常持握 */
    x = bx; y = by; z = bz; rx = 0; ry = 0; rz = 0;
  }
  weaponGroup.position.set(x, y, z);
  weaponGroup.rotation.set(rx, ry, rz);
  weaponGroup.visible = true;
  /* 【1.10.10】枪飞起来时左手必须彻底离开画面。
     ⚠️ 上一版只设 visible=false —— leftHandAnchor 是 weaponGroup 的子节点，
        updateLeftHand 每帧都会把它设回 visible=true，于是"左手跟着枪一起飞"（用户报的现象）。
        现在**直接把它挪到画面外**（枪局部 y=-3），visible 也关，双保险。 */
  try {
    if (typeof leftHandAnchor !== 'undefined' && leftHandAnchor) {
      leftHandAnchor.position.set(0, -3, -1);
      leftHandAnchor.visible = false;
    }
    if (typeof _holdHand !== 'undefined' && _holdHand) _holdHand.visible = false;
    var _rh = weaponGroup.userData._右手;
    if (_rh) _rh.visible = true;
  } catch (e) { }
  /* 检视期间强制退出开镜：否则枪一边飞一边保持 adsFov，画面像被望远镜怼住 */
  try {
    if (S.aiming || S.aimProgress > 0) {
      S.aiming = false; S.aimProgress = 0;
      camera.fov = 75; camera.updateProjectionMatrix();
    }
  } catch (e) { }
}

/* ==================== 八、换弹：弹夹从屏幕左侧飘来、左手伸过去接 ====================
   时间轴（a = 换弹进度）：
     0.26~0.40  左手向屏幕左侧伸出去
     0.34       弹夹从画面左外飘入
     0.40~0.50  弹夹飞到左手心
     0.50       交接给左手（attach 保持世界变换，不跳）
     0.48~0.62  手带着弹夹收回枪身
   飞匣挂在相机下（不是 weaponGroup），这样它才能在"枪之外"飞。 */
var 引力_飞匣 = null;
function 引力_飞匣挂载中() { return !!(引力_飞匣 && 引力_飞匣.挂载); }
function 引力_飞匣开始(mag) {
  if (!mag) return false;
  try {
    if (引力_飞匣 && 引力_飞匣.obj && 引力_飞匣.obj.parent) 引力_飞匣.obj.parent.remove(引力_飞匣.obj);
  } catch (e) { }
  引力_飞匣 = { obj: mag, 挂载: true, t: 0, 出发: false };
  /* 起点：画面左侧外（相机局部） */
  camera.add(mag);
  mag.position.set(-0.62, -0.30, -0.80);
  mag.rotation.set(0.35, 0.9, 0.45);
  mag.scale.setScalar(1);
  return true;
}
function 引力_飞匣Tick(a) {
  var F = 引力_飞匣; if (!F || !F.挂载) return;
  /* 换弹结束/被取消 → 飞匣直接清掉，别留在画面上 */
  if (!S.reloading) { 引力_飞匣清理(); return; }
  var o = F.obj; if (!o || !o.parent) { 引力_飞匣 = null; return; }
  /* 【1.10.10】飞行区间 0.42→0.56：弹匣本来就是 a=0.42 才创建，
     上一版按 0.34 起算 → 一出现就已在半路，看不出"从左边飘来"。 */
  var t = (a - 0.42) / 0.14;
  t = Math.max(0, Math.min(1, t));
  var k = 引力_检视平滑(t);
  var 起x = -0.62, 起y = -0.30, 起z = -0.80;
  var 止x = -0.255, 止y = -0.290, 止z = -0.520;
  o.position.set(起x + (止x - 起x) * k, 起y + (止y - 起y) * k + Math.sin(k * Math.PI) * 0.035,
    起z + (止z - 起z) * k);
  /* 一路转正（飘过来的时候是歪的，快到手里时已经扶正） */
  o.rotation.set(0.35 * (1 - k) + 0.35 * k * 0.4, 0.9 * (1 - k), 0.45 * (1 - k));
}
function 引力_飞匣交接(anchor, mag) {
  var F = 引力_飞匣; if (!F || !F.挂载) return;
  try {
    anchor.attach(mag);                       /* attach 保持世界变换 → 视觉上不跳 */
    mag.position.set(0.010, -0.026, -0.020);
    mag.rotation.set(0.5, 0, 0.3);
  } catch (e) {
    try { anchor.add(mag); mag.position.set(0.010, -0.026, -0.020); mag.rotation.set(0.5, 0, 0.3); } catch (e2) { }
  }
  F.挂载 = false; F.obj = null;
}
function 引力_飞匣清理() {
  var F = 引力_飞匣; if (!F) return;
  if (F.挂载 && F.obj && F.obj.parent) { try { F.obj.parent.remove(F.obj); } catch (e) { } }
  引力_飞匣 = null;
}
/* 左手向画面左侧伸（由 js/24 在设完普通换弹手位之后调，覆盖成"够过去"） */
function 引力_手偏移(a) {
  if (!引力_是当前枪()) return;
  var t = 0;
  /* 【1.10.10】和飞匣对齐：弹匣 0.42 才出现、0.56 到手，手要在这段伸出去等它 */
  if (a >= 0.34 && a < 0.46) t = (a - 0.34) / 0.12;
  else if (a >= 0.46 && a < 0.56) t = 1;
  else if (a >= 0.56 && a < 0.70) t = 1 - (a - 0.56) / 0.14;
  if (t <= 0) return;
  var k = 引力_检视平滑(t);
  try {
    leftHandAnchor.position.x -= 0.255 * k;      /* 枪局部 -x = 屏幕左侧 */
    leftHandAnchor.position.y += 0.035 * k;
    leftHandAnchor.position.z += 0.075 * k;
    leftHandAnchor.visible = true;
  } catch (e) { }
}

/* ==================== 六、对外 ==================== */
try {
  window.引力枪皮 = {
    名: 引力枪皮名, 槽: GRAVITY_SLOT, 价: 引力皮价,
    已解锁: 引力已解锁, 解锁: 引力解锁, 刷新锁: 引力刷新锁, 购买: 引力购买尝试,
    装备: function () { try { curGun = GRAVITY_SLOT; currentWeapon = WEAPON_GUN; rebuildWeaponModel(); } catch (e) { } }
  };
} catch (e) { }
