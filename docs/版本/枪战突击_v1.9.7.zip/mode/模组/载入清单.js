// 装了模组就把文件名（不用写 .js）加进这个数组，按顺序加载。
// 例：window.MOD_FILES = ['角色_夜莺', '爪刀'];
window.MOD_FILES = [];
