/* 【batch244】载具系统（js/65_载具.js）—— **故意藏在最后、不接任何 UI** ====================
   用途：给以后的「赛车场」地图铺路。现在游戏里**没有任何入口**能碰到它：
     · 菜单、选图、设置面板里都不会出现一个字；
     · 只有控制台 / 模组 / 以后的赛车场地图能调它；
     · 平时不跑任何逻辑（没有载具、没在开车时，每帧只做一次 if 判断，开销 ≈ 0）。

   对外接口（都挂在 window.载具 上，全中文）：
     载具.定义(def)              注册一种车型（以后赛车场地图/模组用）
     载具.生成(id,x,z)           在(x,z)放一辆车，返回车的句柄
     载具.清空()                 收掉场上所有车
     载具.最近的车(x,z,半径)     找最近的一辆
     载具.让玩家上车(车)         直接把玩家塞进驾驶位（脚本/剧情用）
     载具.让玩家下车()
     载具.在开车()               现在是否在驾驶
     载具.车型(id)               取车型定义
   def 字段：
     {id:'赛车', 名:'赛车', 长:4.4, 宽:2.0, 高:1.15, 极速:34, 加速:13, 倒车:12,
      转向:1.9, 抓地:3.2, 生命:900, 颜色:0xd94b3a, 车轮:0.44, 轮距:0.86, 轴距:1.45,
      重力:24, 起跳系数:1.0,         ← batch255 竖直物理：车不会自己飞，只有冲坡/掉台才腾空
      第三人称:{高:2.35, 远:7.4}}
   【为什么现在先做】赛车场那张图要的是"能开、能撞、视角顺手"这三件事，
   这三件事跟地图无关。先把底盘/轮胎/油门/漂移/上下车做扎实，以后加图只要放车、调数值。
   【已知边界】多人里不作为权威载具（不同步位置）——等赛车场真的做了再跟服务端一起定协议，
   现在硬塞只会让联机多一份不可信状态。
*/
var 载具=(function(){
  var 车型表={}, 场上=[], 驾驶=null, 上一帧=0;
  var 提示冷却=0;

  /* ---------- 默认车型：一辆能开的赛车（以后的赛车场直接用）---------- */
  var 默认={
    id:'赛车', 名:'赛车', 长:4.4, 宽:2.0, 高:1.15,
    极速:34, 加速:13, 倒车:12, 转向:1.9, 抓地:3.2, 生命:900,
    颜色:0xd94b3a, 车轮:0.44, 轮距:0.86, 轴距:1.45,
    重力:24, 起跳系数:1.0,          /* 【batch255】重力 24 m/s²；起跳系数＝冲坡时地面顶起的速度继承多少 */
    第三人称:{高:2.35, 远:7.4}
  };
  function 定义(def){
    if(!def||!def.id){console.warn('载具.定义：缺 id');return null;}
    var d={},k;for(k in 默认)d[k]=默认[k];for(k in def)d[k]=def[k];
    车型表[d.id]=d;return d;
  }
  定义(默认);
  /* 再预置两种，方便以后直接放（现在也没人调） */
  定义({id:'越野车', 名:'越野车', 极速:27, 加速:11, 转向:2.1, 抓地:2.6, 颜色:0x5f7a4a, 长:4.8, 宽:2.2, 高:1.3,
        车轮:0.52, 轴距:1.62, 轮距:0.94, 重力:26, 起跳系数:1.15, 第三人称:{高:2.6,远:7.8}});
  定义({id:'摩托', 名:'摩托', 极速:38, 加速:16, 转向:2.4, 抓地:4.2, 颜色:0xd8443c, 长:2.2, 宽:0.7, 高:0.95, 车轮:0.34, 轮距:0, 轴距:0.8, 重力:22, 起跳系数:0.85, 第三人称:{高:1.9,远:5.6}});

  /* ---------- 建模（batch253 重做：从"方盒子"升级成分车型的成品车）---------------
     全部纯几何体拼装（不加载外部模型，保持单文件 / 离线可用）：
       · 车身：侧视轮廓 Extrude（跑车低趴流线 / 越野车方箱 / 摩托三角车架）
       · 细节：轮拱、灯组、格栅、后视镜、尾翼、行李架、射灯、备胎、前叉、车把、排气
     ⚠️【车头方向】物理里车头朝 **-z**（`fx=-sin(yaw), fz=-cos(yaw)`，前进＝-z），
        而建模习惯把车头画在 +z —— 所以所有部件都塞进 `壳`，再整体 `rotation.y=PI` 摆正。
        连带 驾驶Tick 里两处符号要反：轮子滚动 `-car.轮角`、前轮转向 `-car.转向*0.5`。
        **别再往 g 上直接 add**，否则车会"倒着跑、车头灯长在车尾"。 */
  function 建车(d){
    var 车漆=new THREE.MeshPhongMaterial({color:d.颜色,shininess:64,specular:0x555555});
    var 哑光=new THREE.MeshPhongMaterial({color:0x15171a,shininess:10});
    var 玻璃=new THREE.MeshPhongMaterial({color:0x2e5a75,shininess:140,specular:0xaaddff,transparent:true,opacity:0.48});
    var 白光=new THREE.MeshBasicMaterial({color:0xfff6d2});
    var 红  =new THREE.MeshBasicMaterial({color:0xff2b2b});
    var 银  =new THREE.MeshPhongMaterial({color:0xa8adb4,shininess:110,specular:0xffffff});
    var 钢  =new THREE.MeshPhongMaterial({color:0x4a4e54,shininess:90,specular:0x888888});
    var 胶  =new THREE.MeshPhongMaterial({color:0x121316,shininess:6});

    var g=new THREE.Group(), 壳=new THREE.Group();
    壳.rotation.y=Math.PI; g.add(壳);

    var 长=d.长, 宽=d.宽, 高=d.高, R=d.车轮, 半=长/2, 半W=宽/2;
    var 轴距=d.轴距||(长*0.33), 轮距=d.轮距||(宽*0.43);

    function 块(mat,w,h,dep,x,y,z,rx,ry,rz){
      var m=new THREE.Mesh(new THREE.BoxGeometry(w,h,dep),mat);
      m.position.set(x||0,y||0,z||0);m.rotation.set(rx||0,ry||0,rz||0);壳.add(m);return m;
    }
    function 管(mat,r1,r2,h,x,y,z,rx,ry,rz){
      var m=new THREE.Mesh(new THREE.CylinderGeometry(r1,r2,h,12),mat);
      m.position.set(x||0,y||0,z||0);m.rotation.set(rx||0,ry||0,rz||0);壳.add(m);return m;
    }
    /* 侧视轮廓挤出：pts=[[z,y],…]（自动闭合），厚度＝车宽，沿 X 居中 */
    function 壳片(pts,厚,mat){
      var s=new THREE.Shape();s.moveTo(pts[0][0],pts[0][1]);
      for(var i=1;i<pts.length;i++)s.lineTo(pts[i][0],pts[i][1]);
      s.closePath();
      var geo=new THREE.ExtrudeGeometry(s,{depth:厚,bevelEnabled:true,bevelSize:0.02,bevelThickness:0.02,bevelSegments:1,curveSegments:4});
      geo.rotateY(-Math.PI/2);geo.translate(厚/2,0,0);
      var m=new THREE.Mesh(geo,mat);壳.add(m);return m;
    }
    /* 车轮：胎 + 毂 + 5 根辐条
       ⚠️【batch254】拆成**两层**（这是"转向时前轮乱转"的根因）：
         · 外层 `转向组` 只绕 Y 转（打方向盘）
         · 内层 `滚`   只绕 X 转（车轮自转）
       以前两个角度写在**同一个** Object3D 的 rotation.x / rotation.y 上，
       three 的 Euler('XYZ') 是 **先绕 X 再把结果绕 Y** —— 也就是说车轮是"绕车身横向的轴"
       在自转，而不是"绕自己被打歪后的轴"自转。方向一打，轮子就像在胎里乱搅。
       嵌套之后矩阵变成 Ry·Rx，才是真的"先把轮子转向、再绕自己的轴滚"。 */
    function 造轮(px,pz,前,轮R,轮宽){
      var 转向组=new THREE.Group();      /* 外层：打方向（绕 Y） */
      var 滚=new THREE.Group();          /* 内层：滚动（绕 X） */
      转向组.add(滚);
      var 胎=new THREE.Mesh(new THREE.CylinderGeometry(轮R,轮R,轮宽,18),胶);胎.rotation.z=Math.PI/2;滚.add(胎);
      var 毂=new THREE.Mesh(new THREE.CylinderGeometry(轮R*0.58,轮R*0.58,轮宽*0.94,12),银);毂.rotation.z=Math.PI/2;滚.add(毂);
      for(var i=0;i<5;i++){
        var 辐=new THREE.Mesh(new THREE.BoxGeometry(轮宽*0.55,轮R*1.02,0.05),哑光);
        辐.rotation.x=i*Math.PI*2/5;滚.add(辐);
      }
      转向组.position.set(px,轮R,pz);壳.add(转向组);
      return {g:转向组, 滚:滚, 前:!!前};
    }
    /* 轮拱（半环，贴在轮胎外侧平面） */
    function 轮拱(px,pz,轮R,管粗){
      var m=new THREE.Mesh(new THREE.TorusGeometry(轮R*1.14,管粗||0.055,6,12,Math.PI),哑光);
      m.position.set(px,轮R,pz);m.rotation.y=Math.PI/2;壳.add(m);
    }

    var 轮=[], i, sx, sz;
    if(d.id==='摩托'){
      /* ==================== ① 摩托：三角车架 + 前叉 + 车把 ==================== */
      /* 发动机 + 两根斜梁 */
      块(哑光, 0.44, 高*0.36, 长*0.34, 0, 高*0.52, 0.02);
      for(i=-1;i<=1;i+=2)管(车漆, 0.045,0.045, 长*0.42, i*0.10, 高*0.66, -0.02, 0.55,0,0);
      /* 油箱（上宽下窄）+ 座垫 + 上翘尾段 */
      块(车漆, 宽*0.62, 高*0.24, 长*0.34, 0, 高*0.86, 长*0.10);
      块(车漆, 宽*0.44, 高*0.14, 长*0.20, 0, 高*0.98, 长*0.20);
      块(哑光, 宽*0.52, 0.10, 长*0.30, 0, 高*0.92, -长*0.16);
      块(车漆, 宽*0.40, 0.07, 长*0.20, 0, 高*1.00, -长*0.30, -0.18,0,0);
      /* 前叉 + 前挡泥板 + 车把 + 前灯 */
      for(i=-1;i<=1;i+=2)管(银, 0.04,0.04, 高*0.62, i*0.11, 高*0.62, 轴距*0.92, 0.34,0,0);
      块(车漆, 宽*0.46, 0.06, 长*0.20, 0, 高*0.52, 轴距*1.02);
      管(哑光, 0.03,0.03, 宽*1.02, 0, 高*0.96, 轴距*0.86, 0,0,Math.PI/2);
      管(白光, 0.12,0.12, 0.05, 0, 高*0.82, 轴距*1.04, Math.PI/2,0,0);
      /* 后视镜×2 */
      for(i=-1;i<=1;i+=2){
        管(哑光, 0.02,0.02, 0.22, i*0.30, 高*1.06, 轴距*0.82, 0,0,i*0.40);
        块(哑光, 0.09,0.06,0.03, i*0.40, 高*1.16, 轴距*0.82);
      }
      /* 排气（中段 + 尾段） */
      管(钢, 0.055,0.055, 长*0.30, 0.20, 高*0.34, -长*0.06, 0,0,Math.PI/2);
      管(钢, 0.075,0.075, 长*0.14, 0.22, 高*0.30, -长*0.28, Math.PI/2,0,0);
      /* 前后各一轮，细胎 */
      轮.push(造轮(0,  轴距, true,  R*0.98, 0.13));
      轮.push(造轮(0, -轴距, false, R*0.98, 0.16));
    }else if(d.id==='越野车'){
      /* ==================== ② 越野车：方箱 + 行李架 + 射灯 + 备胎 ==================== */
      var 身H=高*0.52;
      块(哑光, 宽*1.02, 高*0.20, 长*1.01, 0, 高*0.30, 0);                    /* 下裙 */
      块(车漆, 宽*0.98, 身H,    长*0.99, 0, 高*0.30+身H*0.6, 0);            /* 车身 */
      块(车漆, 宽*0.92, 高*0.10, 长*0.30, 0, 高*0.62, 半*0.62);             /* 引擎盖 */
      块(车漆, 宽*0.90, 高*0.42, 长*0.52, 0, 高*0.86, -半*0.16);            /* 车顶棚 */
      /* 玻璃：前风挡（略斜）+ 两侧窗 + 后窗 */
      块(玻璃, 宽*0.86, 高*0.30, 0.05, 0, 高*0.90, 半*0.14, -0.18,0,0);
      块(玻璃, 0.04, 高*0.26, 长*0.44, -(宽*0.45), 高*0.92, -半*0.18);
      块(玻璃, 0.04, 高*0.26, 长*0.44,  (宽*0.45), 高*0.92, -半*0.18);
      块(玻璃, 宽*0.80, 高*0.26, 0.05, 0, 高*0.92, -半*0.44);
      /* 保险杠 + 绞盘 + 拖车钩 */
      块(哑光, 宽*1.06, 高*0.16, 长*0.07, 0, 高*0.34, 半*1.02);
      块(哑光, 宽*1.06, 高*0.14, 长*0.06, 0, 高*0.34, -半*1.02);
      管(银, 0.10,0.10, 宽*0.30, 0, 高*0.44, 半*1.06, 0,0,Math.PI/2);
      /* 圆灯×2 + 转向灯 + 竖条尾灯 */
      for(i=-1;i<=1;i+=2){
        管(白光, 0.13,0.13, 0.06, i*宽*0.30, 高*0.52, 半*1.005, Math.PI/2,0,0);
        块(白光, 宽*0.10, 0.05, 0.04, i*宽*0.13, 高*0.40, 半*1.03);
        块(红, 0.09, 高*0.16, 0.05, i*宽*0.40, 高*0.52, -半*1.005);
      }
      /* 车顶行李架（2 纵 3 横）+ 4 个射灯 */
      块(哑光, 0.06, 0.06, 长*0.56, -宽*0.40, 高*1.10, -半*0.14);
      块(哑光, 0.06, 0.06, 长*0.56,  宽*0.40, 高*1.10, -半*0.14);
      for(i=0;i<3;i++)块(哑光, 宽*0.86, 0.05, 0.05, 0, 高*1.10, -半*0.36+i*长*0.22);
      for(i=0;i<4;i++){
        管(白光, 0.075,0.075, 0.07, (i<2?-1:1)*宽*0.30, 高*1.16, -半*0.32+(i%2)*长*0.10, Math.PI/2,0,0);
      }
      /* 尾门备胎 + 侧踏板 */
      管(胶, R*0.96, R*0.96, 0.22, 0, 高*0.60, -半*1.10, Math.PI/2,0,0);
      管(银, R*0.34, R*0.34, 0.24, 0, 高*0.60, -半*1.10, Math.PI/2,0,0);
      块(哑光, 0.20, 0.08, 长*0.40, -(半W+0.04), 高*0.18, 0);
      块(哑光, 0.20, 0.08, 长*0.40,  (半W+0.04), 高*0.18, 0);
      /* 四个大胎 + 粗轮拱 */
      for(i=0;i<4;i++){
        sx=(i%2===0?-1:1);sz=(i<2?1:-1);
        轮.push(造轮(sx*(半W-0.02), sz*轴距, sz>0, R, 0.34));
        轮拱(sx*(半W-0.01), sz*轴距, R*1.06, 0.085);
      }
    }else{
      /* ==================== ③ 跑车（默认外观，尺寸跟着 def 走）==================== */
      /* 主车身：低趴流线（前低后高、尾部收） */
      壳片([
        [-半,高*0.24],[-半,高*0.56],[-半*0.62,高*0.62],[-半*0.10,高*0.64],
        [ 半*0.34,高*0.62],[ 半*0.72,高*0.54],[ 半,高*0.40],[ 半,高*0.24]
      ], 宽*0.99, 车漆);
      /* 座舱罩（玻璃拱，比车身略窄） */
      壳片([
        [-半*0.44,高*0.62],[-半*0.34,高*0.99],[半*0.06,高*0.99],[半*0.30,高*0.62]
      ], 宽*0.90, 玻璃);
      /* 引擎盖进气口 + 车顶鲨鱼鳍 */
      块(哑光, 宽*0.42, 0.05, 长*0.14, 0, 高*0.645, 半*0.34, 0.03,0,0);
      块(哑光, 0.06, 高*0.10, 长*0.10, 0, 高*0.99, -半*0.12);
      /* 侧裙 / 前唇 / 后扩散器 */
      块(哑光, 0.10, 高*0.12, 长*0.52, -(半W-0.02), 高*0.22, 0);
      块(哑光, 0.10, 高*0.12, 长*0.52,  (半W-0.02), 高*0.22, 0);
      块(哑光, 宽*0.96, 0.07, 长*0.10, 0, 高*0.19, 半*0.97);
      块(哑光, 宽*0.92, 0.10, 长*0.08, 0, 高*0.21, -半*0.97);
      /* 灯：横贯日行灯 + 两侧主灯 + 尾灯带 */
      块(白光, 宽*0.62, 0.035, 0.045, 0, 高*0.46, 半*1.000);
      块(白光, 宽*0.20, 0.09,  0.06,  -宽*0.30, 高*0.40, 半*0.995);
      块(白光, 宽*0.20, 0.09,  0.06,   宽*0.30, 高*0.40, 半*0.995);
      块(红, 宽*0.66, 0.05, 0.04, 0, 高*0.50, -半*1.000);
      块(红, 宽*0.22, 0.08, 0.05, -宽*0.28, 高*0.44, -半*0.995);
      块(红, 宽*0.22, 0.08, 0.05,  宽*0.28, 高*0.44, -半*0.995);
      /* 前格栅（三条横杆） */
      块(哑光, 宽*0.50, 高*0.12, 0.05, 0, 高*0.30, 半*1.005);
      for(i=0;i<3;i++)块(银, 宽*0.46, 0.015, 0.02, 0, 高*0.265+i*0.028, 半*1.02);
      /* 后视镜 */
      for(i=-1;i<=1;i+=2){
        块(哑光, 0.16, 0.03, 0.03, i*(半W-0.02), 高*0.66, 半*0.44);
        块(车漆, 0.10, 0.07, 0.17, i*(半W+0.05), 高*0.68, 半*0.44);
      }
      /* 尾翼 */
      块(车漆, 宽*0.94, 0.06, 长*0.09, 0, 高*0.88, -半*0.88);
      块(哑光, 0.07, 高*0.22, 0.09, -宽*0.33, 高*0.75, -半*0.88);
      块(哑光, 0.07, 高*0.22, 0.09,  宽*0.33, 高*0.75, -半*0.88);
      /* 排气 */
      管(钢, 0.055,0.055, 0.14, -宽*0.26, 高*0.22, -半*1.02, Math.PI/2,0,0);
      管(钢, 0.055,0.055, 0.14,  宽*0.26, 高*0.22, -半*1.02, Math.PI/2,0,0);
      /* 四个轮 + 轮拱 */
      for(i=0;i<4;i++){
        sx=(i%2===0?-1:1);sz=(i<2?1:-1);
        轮.push(造轮(sx*(半W-0.05), sz*轴距, sz>0, R, 0.26));
        轮拱(sx*(半W-0.02), sz*轴距, R);
      }
    }
    g.traverse(function(o){o.raycast=function(){};});
    return {g:g,轮:轮};
  }
  /* ---------- 生成 / 清空 ---------- */
  function 生成(id,x,z,yaw){
    var d=车型表[id]||车型表['赛车'];
    var 模=建车(d);
    var y=0;
    try{y=groundHeightAt(x,z,GROUND_Y+2)-GROUND_Y;}catch(e){}
    模.g.position.set(x||0,y,z||0);
    模.g.rotation.y=yaw||0;
    scene.add(模.g);
    var car={def:d,obj:模.g,轮:模.轮,x:x||0,y:y,z:z||0,yaw:yaw||0,
             速:0,vy:0,腾空:false,离地:0,失衡:0,转向:0,生命:d.生命,漂移:0,轮角:0,冲撞冷却:0,发动机:0};
    场上.push(car);
    return car;
  }
  function 清空(){
    for(var i=场上.length-1;i>=0;i--){var c=场上[i];if(c.obj&&c.obj.parent)c.obj.parent.remove(c.obj);}
    场上.length=0;驾驶=null;
  }
  function 最近的车(x,z,r){
    var best=null,bd=(r||4)*(r||4);
    for(var i=0;i<场上.length;i++){
      var c=场上[i],dx=c.x-x,dz=c.z-z,d2=dx*dx+dz*dz;
      if(d2<bd){bd=d2;best=c;}
    }
    return best;
  }
  /* ---------- 上车 / 下车 ---------- */
  function 上车(car){
    if(!car||驾驶)return false;
    驾驶=car;
    try{
      if(typeof weaponGroup!=='undefined'&&weaponGroup)weaponGroup.visible=false;
      if(typeof leftHandCamGroup!=='undefined'&&leftHandCamGroup)leftHandCamGroup.visible=false;
      document.getElementById('crosshair').style.opacity='0';
    }catch(e){}
    上一帧=performance.now();
    try{if(typeof showMsg==='function')showMsg('🚗 已上车：W/S 油门·倒车　A/D 转向　空格 手刹　F 下车','#9bd4ff');}catch(e){}
    return true;
  }
  function 下车(){
    if(!驾驶)return;
    var car=驾驶;
    /* 【batch256】只有真的"悬在空中"才不许下车。
       以前还判 car.腾空——但贴着坡面、停在崖边都会把腾空置 true，结果按 F 直接被拒。 */
    if((car.离地||0)>1.2){
      try{if(typeof showMsg==='function')showMsg('先落回地面再下车（现在离地 '+(Math.max(0,car.离地||0)).toFixed(1)+' 米）','#ffb347');}catch(e){}
      return;
    }
    var 侧x=car.x+Math.cos(car.yaw)*1.9, 侧z=car.z-Math.sin(car.yaw)*1.9;
    /* 门被堵就换另一侧 */
    try{
      if(typeof isColliding==='function'&&isColliding(侧x,侧z,0.5)){侧x=car.x-Math.cos(car.yaw)*1.9;侧z=car.z+Math.sin(car.yaw)*1.9;}
    }catch(e){}
    try{camera.position.set(侧x,groundHeightAt(侧x,侧z,GROUND_Y+2),侧z);S.velY=0;S.onGround=true;}catch(e){}
    驾驶=null;
    try{
      if(typeof weaponGroup!=='undefined'&&weaponGroup)weaponGroup.visible=true;
      document.getElementById('crosshair').style.opacity='';
    }catch(e){}
    try{if(typeof showMsg==='function')showMsg('已下车','#9bd4ff');}catch(e){}
  }
  /* ---------- 键盘：只在开车（或车就在脚边）时接管 ---------- */
  var 键={w:false,s:false,a:false,d:false,空格:false};
  document.addEventListener('keydown',function(e){
    if(typeof 正在打字==='function'&&正在打字())return;
    if(e.code==='KeyF'&&!e.repeat){
      if(驾驶){e.preventDefault();下车();return;}
      if(typeof S!=='undefined'&&S.playing&&!S.over&&!S.paused){
        var c=最近的车(camera.position.x,camera.position.z,4.2);
        if(c){e.preventDefault();上车(c);return;}
      }
    }
    if(!驾驶)return;
    if(e.code==='KeyW'||e.code==='ArrowUp'){键.w=true;e.preventDefault();}
    else if(e.code==='KeyS'||e.code==='ArrowDown'){键.s=true;e.preventDefault();}
    else if(e.code==='KeyA'||e.code==='ArrowLeft'){键.a=true;e.preventDefault();}
    else if(e.code==='KeyD'||e.code==='ArrowRight'){键.d=true;e.preventDefault();}
    else if(e.code==='Space'){键.空格=true;e.preventDefault();}
  },true);
  document.addEventListener('keyup',function(e){
    if(e.code==='KeyW'||e.code==='ArrowUp')键.w=false;
    else if(e.code==='KeyS'||e.code==='ArrowDown')键.s=false;
    else if(e.code==='KeyA'||e.code==='ArrowLeft')键.a=false;
    else if(e.code==='KeyD'||e.code==='ArrowRight')键.d=false;
    else if(e.code==='Space')键.空格=false;
  },true);

  /* ---------- 物理 + 视角（每帧，只在驾驶时跑）---------- */
  function 驾驶Tick(){
    var car=驾驶;if(!car)return;
    var now=performance.now();
    var dt=Math.min(0.05,(now-上一帧)/1000)||0.016;上一帧=now;
    if(!S.playing||S.over||S.hp<=0){下车();return;}
    var d=car.def;
    /* ================= 【batch255】竖直方向：重力 + 地形约束 → 落差腾空 =================
       ⚠️ 上一版（254）做错了：搞成"速度够快升力压过车重就自动起飞"。用户要的不是飞机，
          是**车跑过有高低落差的地方会飞起来一下**（冲上坡顶、从台子上掉下去）。
       现在只做两件事，就是初中物理的抛体运动：
         ① 每帧给车一个向下的重力加速度：v_y -= g·dt，y += v_y·dt
         ② 地面托住车：y 掉到地面以下就压回地面，并把向下的速度吃掉（落地）
       剩下全交给地形自然产生：
         · 平地/缓坡：重力每帧把车压回地面 → 贴地跑，一点不飘
         · 冲上坡顶：地面把车往上顶，车带着这个向上的速度冲出去 → 抛物线，飞一段再落下
         · 掉下台阶/陡坎：地面突然降下去，车还停在高处 → 自由落体掉下来
       所以"能不能飞"取决于落差和速度，不取决于有没有到某个速度。 */
    var 腾空=!!car.腾空;
    /* 轮子离地就没有抓地力了：空中不能踩油门加速，也不能靠方向盘转向（只有惯性） */
    var 抓地=腾空?0:1;
    /* 油门 / 刹车 / 倒车 */
    var 油门=(键.w?1:0)-(键.s?1:0);
    if(油门>0)car.速+=d.加速*抓地*dt;
    else if(油门<0)car.速-=(car.速>0?d.加速*1.6:d.倒车*0.9)*抓地*dt;
    else car.速-=car.速*Math.min(1,(腾空?0.22:2.4)*dt);
    if(键.空格&&!腾空)car.速-=car.速*Math.min(1,6.5*dt);      // 手刹（空中踩了没用）
    car.速=Math.max(-d.倒车,Math.min(d.极速,car.速));
    /* 转向：速度越低越转不动（原地打方向盘没用）；轮子离地就几乎转不动 */
    var 转向输入=(键.a?1:0)-(键.d?1:0);
    var 有效=Math.min(1,Math.abs(car.速)/6)*(腾空?0.06:1);
    car.转向+=(转向输入-car.转向)*Math.min(1,8*dt);
    car.yaw+=car.转向*d.转向*有效*dt*(car.速>=0?1:-1);
    /* 位置推进 + 碰撞（撞墙就把速度吃掉大半，并往切线方向滑一下） */
    var fx=-Math.sin(car.yaw),fz=-Math.cos(car.yaw);
    var nx=car.x+fx*car.速*dt, nz=car.z+fz*car.速*dt;
    var 撞了=false;
    try{
      var r=Math.max(d.宽*0.62,0.9);
      /* 第 4 参＝车身离地高度、第 5 参＝台阶容差：这样 0.1 米的路沿、矮台不会把车顶住
         （不给这两个参数的话，神道那种 0.12 高的铺石会把车"卡在原地"，实测踩油门不动） */
      var 车高=car.y+GROUND_Y+0.45;
      if(typeof isColliding==='function'&&isColliding(nx,nz,r,车高,true))撞了=true;
      if(!撞了&&typeof worldLimit==='function'&&(Math.abs(nx)>worldLimit()-2||Math.abs(nz)>worldLimit()-2))撞了=true;
    }catch(e){}
    if(撞了){
      /* 只前进方向被挡：沿"横向"滑一小段，避免贴墙卡死 */
      var 侧x=-fz,侧z=fx;
      var 滑=car.速*dt*0.35;
      var tx=car.x+侧x*滑, tz=car.z+侧z*滑;
      try{
        if(typeof isColliding!=='function'||!isColliding(tx,tz,d.宽*0.62,car.y+GROUND_Y+0.45,true)){car.x=tx;car.z=tz;}
      }catch(e){}
      if(Math.abs(car.速)>9){try{spawnParticle(new THREE.Vector3(car.x,car.y+0.8,car.z),0xffcf6a,8,0.25);}catch(e){}}
      car.速*=-0.18;
    }else{car.x=nx;car.z=nz;}
    /* ---------- 竖直方向：重力 / 落地 / 落差腾空 / 崖边倾覆 ----------
       ① 重力：v_y -= g·dt　② 积分：y += v_y·dt　③ 地面托底（y 压回地面）
       诀窍：地面往上升（冲坡）时把地面上升的速度记进 v_y → 冲出坡顶自然带着速度飞出去。

       【batch256】崖边倾覆 —— 不用"拽出去""插进山体再挤出来"这类补丁，
       直接在**四个轮子**的位置各探一次地面，数还有几只轮子踩在地上：
         · ≥3 只踩地 → 车稳；车身姿态按支撑面拟合（上下坡、斜坡自然仰起/侧倾）
         · ≤2 只（车头/车尾/一侧整条出崖）→ 重心已悬在支撑边外，车绕**支撑边**倾倒：
             角加速度 α = g·d / k²
               d  ＝重心到支撑边的水平距离（前后倒≈半长，左右倒≈半宽）
               k² ＝(长²+高²)/12，车身绕横轴的迴转半径平方
             前倒＝绕后轴、车头往下栽；侧倒＝绕另一侧、车身翻下去。
           倾倒时重心一边降低一边朝悬空方向移动：
             h ＝ 支撑面高度 − d·sin(角)　　（高度）
             位移＝ d·(1−cos(角))　　　　　（水平，朝悬空那侧）
           所以车是"翻着、滑着"出去的，转角到 ≈77° 重心越过支点 → car.掉下=true，
           剩下的交给重力（真正的自由落体）。
         · 腾空飞行（一只轮子都踩不到）不算倾覆，走正常重力。 */
    var 地面=car.y;
    try{
      /* 第 3 参按"车身此刻的高度"探，坡顶 / 台面上空才能拿到正确的地面高度 */
      地面=groundHeightAt(car.x,car.z,car.y+GROUND_Y+0.8)-GROUND_Y;
    }catch(e){}
    var 地Prev=(car.地基===undefined)?地面:car.地基;
    /* 地面本身在升降的速度（冲坡为正、下坡为负），限幅防坡面接缝处爆数 */
    var 地速=Math.max(-40,Math.min(40,(地面-地Prev)/Math.max(dt,0.001)));
    var g=(d.重力||24);

    /* ---------- 四角探地：哪几只轮子还踩在地上 ---------- */
    var 半长=Math.max(0.9,(d.长||4.4)*0.42), 半宽=Math.max(0.45,(d.宽||2.0)*0.42);
    var 右x=Math.cos(car.yaw), 右z=-Math.sin(car.yaw);      /* 车的右侧方向 */
    var 角地=function(ax,az){
      try{return groundHeightAt(ax,az,car.y+GROUND_Y+1.2)-GROUND_Y;}catch(e){return car.y;}
    };
    var FL=角地(car.x+fx*半长+右x*半宽, car.z+fz*半长+右z*半宽);
    var FR=角地(car.x+fx*半长-右x*半宽, car.z+fz*半长-右z*半宽);
    var BL=角地(car.x-fx*半长+右x*半宽, car.z-fz*半长+右z*半宽);
    var BR=角地(car.x-fx*半长-右x*半宽, car.z-fz*半长-右z*半宽);
    var 深=0.8;                                             /* 差 0.8 米以上才算真悬空（路沿/坡缝不算） */
    var 悬FL=(car.y-FL)>深, 悬FR=(car.y-FR)>深, 悬BL=(car.y-BL)>深, 悬BR=(car.y-BR)>深;
    var 悬角=(悬FL?1:0)+(悬FR?1:0)+(悬BL?1:0)+(悬BR?1:0);
    var 支撑数=4-悬角;
    var 前悬数=(悬FL?1:0)+(悬FR?1:0), 后悬数=(悬BL?1:0)+(悬BR?1:0);
    var 左悬数=(悬FL?1:0)+(悬BL?1:0), 右悬数=(悬FR?1:0)+(悬BR?1:0);
    /* 支撑面高度：只算踩着地的那几只轮子 */
    var 撑高=0,撑n=0;
    if(!悬FL){撑高+=FL;撑n++;}
    if(!悬FR){撑高+=FR;撑n++;}
    if(!悬BL){撑高+=BL;撑n++;}
    if(!悬BR){撑高+=BR;撑n++;}
    if(撑n)撑高/=撑n;
    if(car.倾倒x===undefined)car.倾倒x=0;
    if(car.倾倒z===undefined)car.倾倒z=0;
    if(car.倾ωx===undefined)car.倾ωx=0;
    if(car.倾ωz===undefined)car.倾ωz=0;

    /* 崖边倾覆：还有 1~2 只轮子踩地、车身还贴着地、也没开始掉 */
    var 倾覆中=(!car.掉下) && 支撑数>=1 && 支撑数<=2 && (car.y-地面)<0.6;
    if(倾覆中){
      var L车=(d.长||4.4), H车=(d.高||1.15);
      var k2=Math.max(0.5,(L车*L车+H车*H车)/12);
      var αx=(前悬数!==后悬数)?Math.min(8,g*半长/k2*0.35):0;
      var αz=(左悬数!==右悬数)?Math.min(8,g*半宽/k2*0.55):0;
      if(前悬数>后悬数)car.倾ωx-=αx*dt; else if(后悬数>前悬数)car.倾ωx+=αx*dt;
      if(左悬数>右悬数)car.倾ωz+=αz*dt; else if(右悬数>左悬数)car.倾ωz-=αz*dt;
      car.倾倒x+=car.倾ωx*dt; car.倾倒z+=car.倾ωz*dt;
      var 角x=Math.abs(car.倾倒x), 角z=Math.abs(car.倾倒z), 倒角=Math.max(角x,角z);
      var 臂=(角x>=角z)?半长:半宽, 有效=Math.min(倒角,Math.PI/2);
      /* 重心随转角往下沉 */
      var 支撑Y=撑高-臂*Math.sin(有效);
      car.y=Math.min(car.y,支撑Y);
      /* 重心同时朝悬空那侧平移 d(1-cosθ)：车是翻着滑出去的，不是原地打转 */
      var 前移=臂*(1-Math.cos(有效));
      var Δ=前移-(car.倾移||0); car.倾移=前移;
      if(Δ>0){
        var 移x=0,移z=0;
        if(前悬数>后悬数){移x+=fx;移z+=fz;} else if(后悬数>前悬数){移x-=fx;移z-=fz;}
        if(左悬数>右悬数){移x-=右x;移z-=右z;} else if(右悬数>左悬数){移x+=右x;移z+=右z;}
        if(移x||移z){
          var 移长=Math.sqrt(移x*移x+移z*移z)||1;
          car.x+=移x/移长*Δ; car.z+=移z/移长*Δ;
        }
      }
      car.vy=0; car.腾空=false;
      /* 转到 90°（重心正好在支点正上方）→ 之后支撑边帮不上忙了：
         此时重心绕支点转的水平速度 v = d·ω（朝悬空那侧），带着这个速度交给重力，
         车就会"翻着飞出去"，而不是贴着崖壁垂直掉。 */
      if(倒角>=Math.PI/2-0.03&&!car.掉下){
        car.掉下=true;
        var 方x=0,方z=0;
        if(前悬数>后悬数){方x+=fx;方z+=fz;} else if(后悬数>前悬数){方x-=fx;方z-=fz;}
        if(左悬数>右悬数){方x-=右x;方z-=右z;} else if(右悬数>左悬数){方x+=右x;方z+=右z;}
        var 方长=Math.sqrt(方x*方x+方z*方z)||1;
        var ω=Math.max(Math.abs(car.倾ωx),Math.abs(car.倾ωz));
        car.掉落vx=方x/方长*(臂*ω+0.6);
        car.掉落vz=方z/方长*(臂*ω+0.6);
        car.vy=Math.min(car.vy,0);
      }
    }else{
      /* 正常：重力 + 地面托底（贴地 / 冲坡 / 自由落体） */
      car.vy-=g*dt;
      car.y+=car.vy*dt;
      if(car.掉下){
        /* 翻出崖口以后：保持翻转角速度 + 带着水平速度往下飞（真正的抛体） */
        car.x+=(car.掉落vx||0)*dt; car.z+=(car.掉落vz||0)*dt;
        car.倾倒x+=car.倾ωx*dt; car.倾倒z+=car.倾ωz*dt;
      }
      car.腾空=true;
      if(car.y<=地面+0.02){                       /* 地面托住：落地 / 贴在坡面上 */
        var 落地速=car.vy;
        car.y=地面;
        if(落地速<-8){                            /* 砸得狠：掉速 + 火花 */
          car.速*=0.86;
          try{spawnParticle(new THREE.Vector3(car.x,地面+GROUND_Y+0.3,car.z),0xffd08a,14,0.32,true);}catch(e2){}
        }
        /* 地面往上顶（冲坡）→ 把这个上升速度留给车，冲出坡顶时就变成起跳初速 */
        car.vy=Math.max(0,地速*(d.起跳系数||1));
        car.腾空=false; car.掉下=false; car.掉落vx=0; car.掉落vz=0;
      }else if(car.y-地面<0.16&&car.vy<=0.5){      /* 只差一丁点：吸回地面，免得下坡一路抖 */
        car.y=地面; car.vy=0; car.腾空=false;
      }
    }
    car.地基=地面;
    car.离地=Math.max(0,car.y-地面);
    /* ---------- 车身姿态 ---------- */
    car.obj.position.set(car.x,car.y,car.z);
    car.obj.rotation.y=car.yaw;
    var 俯仰=-(油门)*0.012 + (car.腾空?Math.max(-0.30,Math.min(0.30,-car.vy*0.022)):0);
    var 侧倾=-(car.转向||0)*Math.min(1,Math.abs(car.速)/16)*0.10;
    if(支撑数>=3&&!car.掉下){
      /* 3 只以上踩地：跟着支撑面仰起/侧倾。
         悬空那只角的地面在崖下，直接拿它算会得出夸张角度 → 用同轴/同侧那个角的实测值代替 */
      var fFL=悬FL?FR:FL, fFR=悬FR?FL:FR, fBL=悬BL?BR:BL, fBR=悬BR?BL:BR;
      俯仰+=Math.max(-0.55,Math.min(0.55,Math.atan2(((fFL+fFR)/2)-((fBL+fBR)/2), 半长*2)));
      侧倾+=Math.max(-0.45,Math.min(0.45,Math.atan2(((fFL+fBL)/2)-((fFR+fBR)/2), 半宽*2)));
      /* 回到稳定：倾倒角和角速度慢慢归零 */
      car.倾倒x*=1-Math.min(1,6*dt); car.倾倒z*=1-Math.min(1,6*dt);
      car.倾ωx*=1-Math.min(1,8*dt); car.倾ωz*=1-Math.min(1,8*dt);
      car.倾移=0;
    }
    car.obj.rotation.x=俯仰+car.倾倒x;
    car.obj.rotation.z=侧倾+car.倾倒z;
    car.失衡角=侧倾; car.俯仰角=car.obj.rotation.x;
    /* 轮子：滚动 + 前轮转向（两层：外层转向绕 Y，内层滚动绕 X）
       ⚠️【batch254】滚动角原来的负号是错的，已改回正号。推导：
          模型整体在 `壳` 里转了 180°（绕 Y），所以轮子"局部 +X"在世界里是 **-X**；
          要"车往前（世界 -z）走、轮顶也往 -z 转"，世界角速度必须绕 +X 为负。
          绕 -X 转 a 等于绕 +X 转 -a，所以要世界为负 ⇒ a 必须为正。
          也就是 rotation.x = +轮角。（上一版写了 -轮角，看着就是"往前开轮子倒着滚"。） */
    car.轮角+=car.速*dt/Math.max(0.2,d.车轮);
    for(var i=0;i<car.轮.length;i++){
      var w=car.轮[i];
      var 滚=w.滚||w.g;
      滚.rotation.x=car.轮角;
      if(w.前)w.g.rotation.y=car.转向*0.5;
    }
    /* 撞人：速度够快就把挡在前面的撞飞（载具也是武器） */
    car.冲撞冷却-=dt;
    if(Math.abs(car.速)>7&&car.冲撞冷却<=0){
      for(var k=enemies.length-1;k>=0;k--){
        var e=enemies[k];if(!e||e.isNet)continue;
        if(e.hp<=0)continue;
        var ep=heroEntWorld(e);
        var dx=ep.x-car.x,dz=ep.z-car.z;
        if(dx*dx+dz*dz<4.2){
          if(typeof netIsMulti==='function'&&netIsMulti())continue;
          var 伤=Math.round(Math.abs(car.速)*3.2);
          e.hp-=伤;e.flash=0.3;
          if(e.hb)e.hb.scale.x=Math.max(0,e.hp/e.maxHp);
          if(e.hbMat)e.hbMat.color.setHex(e.hp/e.maxHp>.5?0x00ff00:(e.hp/e.maxHp>.25?0xffff00:0xff0000));
          if(e.hp<=0&&typeof killEnemy==='function')killEnemy(e,k,false);
          car.冲撞冷却=0.5;car.速*=0.82;
          try{spawnParticle(new THREE.Vector3(ep.x,ep.y+1,ep.z),0xff8a3d,12,0.3,true);}catch(_){}
          break;
        }
      }
    }
    /* 相机：车后方第三人称；稍微跟着速度拉远一点 */
    var tp=d.第三人称||{高:2.35,远:7.4};
    var 拉远=tp.远+Math.min(3,Math.abs(car.速)*0.08);
    var camx=car.x-fx*拉远, camz=car.z-fz*拉远;
    var camy=car.y+tp.高;
    try{
      camera.position.x+=(camx-camera.position.x)*Math.min(1,10*dt);
      camera.position.y+=(camy-camera.position.y)*Math.min(1,10*dt);
      camera.position.z+=(camz-camera.position.z)*Math.min(1,10*dt);
      camera.lookAt(car.x+fx*4,car.y+1.05,car.z+fz*4);
    }catch(e){}
    /* 开车的震动（发动机） */
    if(Math.abs(car.速)>1){
      var 抖=0.006*Math.min(1,Math.abs(car.速)/20);
      camera.position.y+=Math.sin(now*0.03)*抖;
    }
    /* 车被打也会掉血（留好接口，以后赛车场里能打爆车） */
    if(car.生命<=0){
      try{spawnParticle(new THREE.Vector3(car.x,car.y+1,car.z),0xff6a2b,26,0.6,true);}catch(e){}
      下车();
      var i2=场上.indexOf(car);if(i2>=0){if(car.obj&&car.obj.parent)car.obj.parent.remove(car.obj);场上.splice(i2,1);}
    }
  }
  /* 玩家位置跟车同步（AI 才会朝车开火 / 敌人子弹有落点） */
  function 同步玩家(){
    if(!驾驶)return;
    try{camera.position.set(camera.position.x,camera.position.y,camera.position.z);}catch(e){}
  }
  return {
    定义:定义,生成:生成,清空:清空,最近的车:最近的车,
    让玩家上车:上车,让玩家下车:下车,在开车:function(){return !!驾驶;},
    车型:function(id){return 车型表[id];},车型表:function(){var a=[],k;for(k in 车型表)a.push(k);return a;},
    当前车:function(){return 驾驶;},
    /* 脚本 / 探针 / 以后的过场动画用：直接给油门与方向，不依赖真键盘
       （名字带下划线＝内部接口，不当作正式玩法入口） */
    _按:function(k,v){ if(Object.prototype.hasOwnProperty.call(键,k))键[k]=!!v; },
    _tick:function(){if(驾驶)驾驶Tick();同步玩家();},
    _有车:function(){return 场上.length>0;}
  };
})();

/* 把 updatePlayer 接管一下：开着车时不让"步行移动"再跑（否则车和玩家会打架）。
   没开车时是一层直通，行为与原来完全一致。 */
var _载_updatePlayer原=updatePlayer;
updatePlayer=function(){
  if(载具.在开车()){载具._tick();return;}
  return _载_updatePlayer原.apply(this,arguments);
};
/* 主循环收尾：驾驶由 updatePlayer 那层接管（这里不能再跑一次，否则一帧算两遍物理）。
   场上有车但没人开的时候，车只是"摆着"，不需要每帧逻辑。 */
function 载具Tick(dt){/* 空实现：留给以后赛车场做"没人开的车也要动"（比如 AI 车） */}
