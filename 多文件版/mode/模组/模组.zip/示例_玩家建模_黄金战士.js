/* ============================================================================
 * 模组示例：把玩家模型刷成金色（改玩家建模）
 * ----------------------------------------------------------------------------
 * 做法：包裹全局 _buildPlayerModel 函数，模型生成后遍历网格把颜色改成金色。
 * 这样你自己看到的、以及别人（联机时）看到的你的模型都会变金。
 *
 * 注册：mode/模组/ 下且载入清单里加 '示例_玩家建模_黄金战士'
 *      或在服务器黑窗口输入： mod on 示例_玩家建模_黄金战士
 * ========================================================================== */
(function () {
  'use strict';
  var _orig = window._buildPlayerModel || (typeof _buildPlayerModel !== 'undefined' ? _buildPlayerModel : null);
  if (!_orig) return;
  window._buildPlayerModel = function () {
    var m = _orig();                       // 先让原版正常生成模型
    if (m && m.root) {
      m.root.traverse(function (o) {
        if (o.isMesh && o.material && o.material.color && o.material.color.setHex) {
          o.material = o.material.clone();  // 克隆材质，避免影响其它玩家 / 敌人
          o.material.color.setHex(0xffd24a);
        }
      });
    }
    return m;
  };
})();
