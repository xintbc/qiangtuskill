/* ============================================================================
 * 模组示例：英雄「烈焰」—— 三个"真正自定义"的技能
 * ----------------------------------------------------------------------------
 * 这个示例演示如何用 ModLoader.addSkill 注册"原版没有的技能效果"。
 * 三个技能全部自己写逻辑，不再复用原版的 dash/shield/eye。
 *
 * 注册方式：把本文件放进 mode/模组/ ，并在 载入清单.js 的数组里加 '示例_角色_烈焰'；
 *          或在服务器黑窗口输入： mod on 示例_角色_烈焰
 * ========================================================================== */
(function () {
  'use strict';
  if (typeof window.ModLoader === 'undefined') return;     // 加载器没就绪就放弃
  if (typeof window.HEROES === 'undefined') return;

  /* 1) 英雄数据（技能 k 用我们自定义的标识，不要和原版重复） */
  var 烈焰 = {
    k: 'blaze', name: '烈焰', tag: '烈焰使者', fac: '未来',
    icon: '🔥', color: 0xff7a3d, css: '#ff7a3d',
    passive: '熔火之躯：受到火焰伤害降低 20%',
    skills: [
      { k: 'blaze_dash',   name: '烈焰突进', icon: '🔥', cd: 9,  dur: 2.5, desc: '触发突进并点燃落点周围敌人' },
      { k: 'blaze_shield', name: '炎之护盾', icon: '🛡', cd: 16, dur: 7,   desc: '展开火焰护盾，灼烧贴脸敌人' },
      { k: 'blaze_nova',   name: '火焰新星', icon: '💥', cd: 14, dur: 0,   desc: '以自身为中心爆发火焰，重创并击退周围敌人' }
    ]
  };
  ModLoader.addHero(烈焰);

  /* 2) 三个自定义技能效果：fn(i, s, H) 返回 true 表示"已被模组处理" */
  // 火焰突进：复用游戏内 dash 加速，并点燃身边敌人
  ModLoader.addSkill('blaze_dash', function () {
    if (typeof SK !== 'undefined' && SK) SK.dashBuff = Math.max(SK.dashBuff || 0, 2.5);
    for (var j = 0; j < enemies.length; j++) {
      var e = enemies[j];
      if (!e || e.isNet) continue;                 // 跳过联机同步来的敌人（它的血量由服务器管）
      var d = Math.hypot(e.root.position.x - camera.position.x, e.root.position.z - camera.position.z);
      if (d <= 4) { e.hp -= 18; if (e.hp <= 0) killEnemy(e, j, false); }
    }
    if (typeof heroFxRingAt === 'function') heroFxRingAt(camera.position.x, camera.position.z, 0xff8a3d, 0.5, 2.2, 0.5);
    return true;
  });

  // 炎之护盾：给自己加护盾，并灼烧贴脸敌人
  ModLoader.addSkill('blaze_shield', function () {
    if (typeof SK !== 'undefined' && SK) SK.shield = Math.max(SK.shield || 0, 7);
    for (var j = 0; j < enemies.length; j++) {
      var e = enemies[j];
      if (!e || e.isNet) continue;
      var d = Math.hypot(e.root.position.x - camera.position.x, e.root.position.z - camera.position.z);
      if (d <= 5) { e.hp -= 22; if (e.hp <= 0) killEnemy(e, j, false); }
    }
    if (typeof heroFxRingAt === 'function') heroFxRingAt(camera.position.x, camera.position.z, 0xffd24a, 0.6, 2.0, 0.6);
    return true;
  });

  // 火焰新星：以自身为中心爆发火焰，重创并击退周围敌人
  ModLoader.addSkill('blaze_nova', function () {
    var radius = 6, dmg = 45;
    if (typeof heroFxRingAt === 'function') heroFxRingAt(camera.position.x, camera.position.z, 0xff5a1f, 0.4, radius, 0.7);
    for (var j = 0; j < enemies.length; j++) {
      var e = enemies[j];
      if (!e || e.isNet) continue;
      var dx = e.root.position.x - camera.position.x, dz = e.root.position.z - camera.position.z;
      var d = Math.hypot(dx, dz);
      if (d <= radius) {
        e.hp -= dmg;
        if (d > 0.01) { var k = 6 / d; e.root.position.x += dx * k; e.root.position.z += dz * k; }  // 击退
        if (e.hp <= 0) killEnemy(e, j, false);
      }
    }
    return true;
  });
})();
