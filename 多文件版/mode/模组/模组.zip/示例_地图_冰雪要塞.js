/* ============================================================================
 * 模组示例：地图「冰雪要塞」
 * ----------------------------------------------------------------------------
 * 用 ModLoader.addMap 往 MAPS 里加一张新地图。build() 里用游戏自带的积木：
 *   makeGround(group, color)   铺地面（第一个参数是地图专属 Group：_mapTarget）
 *   addBox(x,z,w,h,d,mat,kind) 方块；kind='border' 表示边界墙（永远挡人）
 *   addLedge(x,z,w,h,d,mat,kind,y0) 高空方块（二楼楼板/护栏/楼梯；y0 是离地高度）
 *   _tpTarget.push({x,z})      加一个传送点
 * 每张地图用 limit 控制活动半径（单位为米，边界墙放在 limit-1 处）。
 *
 * 注册：mode/模组/ 下且载入清单里加 '示例_地图_冰雪要塞'
 *      或在服务器黑窗口输入： mod on 示例_地图_冰雪要塞
 * ========================================================================== */
(function () {
  'use strict';
  if (typeof window.ModLoader === 'undefined') return;
  if (typeof window.MAPS === 'undefined') return;

  var 冰雪要塞 = {
    id: 'icefort', name: '冰雪要塞', fac: '未来', limit: 56,
    build: function () {
      // 1) 地面（颜色用浅冰蓝）
      makeGround(_mapTarget, 0xcfeaff);

      // 2) 四周边界墙（kind='border'，高度 16）
      addBox(0, -55, 112, 16, 2, null, 'border');
      addBox(0, 55, 112, 16, 2, null, 'border');
      addBox(-55, 0, 2, 16, 112, null, 'border');
      addBox(55, 0, 2, 16, 112, null, 'border');

      // 3) 一楼掩体（mat 传 null → 用默认砖石贴图）
      addBox(0, 0, 10, 5, 10, null);
      addBox(-25, 18, 8, 5, 8, null);
      addBox(25, -18, 8, 5, 8, null);

      // 4) 二楼楼板（y0=5：只在 5~10 米那一层挡人，顶面可站）
      addLedge(0, 0, 44, 5, 32, null, undefined, 5);
      // 二楼护栏
      addBox(0, 15, 44, 1, 1, null);
      addBox(0, -15, 44, 1, 1, null);

      // 5) 楼梯：逐级 addLedge 往上（第 7 参 kind 省略，第 8 参 y0 递增）
      for (var i = 0; i < 6; i++) {
        addLedge(-22 + i * 2.5, 0, 4, 4 + i * 0.8, 7, null, undefined, 4 + i * 0.8);
      }

      // 6) 两个传送点
      _tpTarget.push({ x: -48, z: -48 });
      _tpTarget.push({ x: 48, z: 48 });
    }
  };
  ModLoader.addMap(冰雪要塞);
})();
