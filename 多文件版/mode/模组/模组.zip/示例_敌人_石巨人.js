/* ============================================================================
 * 模组示例：新增敌人「石巨人」
 * ----------------------------------------------------------------------------
 * 用 ModLoader.addEnemyType 往 ETYPES 里加一种新敌人。
 * 默认只在手动生成时出现；想让它随波出现，取消下面 onApply 注释即可。
 *
 * 注册：mode/模组/ 下且载入清单里加 '示例_敌人_石巨人'
 *      或在服务器黑窗口输入： mod on 示例_敌人_石巨人
 * 手动生成：进游戏后在浏览器控制台（F12）输入  odLoader.spawnEneMmy('stone', 0, 10)
 * ========================================================================== */
(function () {
  'use strict';
  if (typeof window.ModLoader === 'undefined') return;
  if (typeof window.ETYPES === 'undefined') return;

  ModLoader.addEnemyType('stone', {
    c: 0x9a8c7a, hp: 120, spd: 0.025, sz: 1.6, sc: 400, dmg: 14, gold: 60, canShoot: false
  });

  /* 想让石巨人从第 3 波起每波自动刷一只，取消下面注释：
  ModLoader.onApply(function () {
    if (typeof nextWave === 'function') {
      var _nw = nextWave;
      nextWave = function () {
        var r = _nw.apply(this, arguments);
        // waveIndex 是全局当前波次；>=3 时额外刷一只石巨人
        if (typeof waveIndex !== 'undefined' && waveIndex >= 3) ModLoader.spawnEnemy('stone', 0, 10);
        return r;
      };
    }
  });
  */
})();
